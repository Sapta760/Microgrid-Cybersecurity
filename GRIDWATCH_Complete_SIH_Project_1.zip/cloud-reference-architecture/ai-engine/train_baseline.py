"""
GRIDWATCH — Baseline model training + evaluation pipeline.

1. Generates (or loads) hours of "normal operation" telemetry.
2. Trains the Isolation Forest on that baseline only (unsupervised —
   we never need labeled attack data to build the detector).
3. Injects synthetic attacks (FDI, replay, DoS, unauthorized command)
   into a held-out evaluation set and reports precision/recall/latency.

Run: python train_baseline.py
Outputs: models/isolation_forest.joblib, evaluation_report.json
"""

import json
import time
import numpy as np
import pandas as pd
from anomaly_detector import GridAnomalyDetector


def generate_baseline(hours: int = 6, hz: float = 1.0) -> pd.DataFrame:
    n = int(hours * 3600 * hz)
    ts = pd.date_range("2026-01-01", periods=n, freq=f"{1/hz}s")
    # realistic diurnal solar/load pattern via slow sine + noise
    t = np.linspace(0, hours, n)
    load_cycle = 1 + 0.15 * np.sin(2 * np.pi * t / 24)
    return pd.DataFrame({
        "timestamp": ts,
        "frequency_hz": 50 + np.random.normal(0, 0.008, n),
        "voltage_v": 230 * load_cycle + np.random.normal(0, 0.6, n),
        "command_ts": ts,
        "auth_valid": True,
        "payload_bytes": [bytes(np.random.randint(0, 255, 16)) for _ in range(n)],
    })


def inject_attack(df: pd.DataFrame, kind: str, start: int, length: int = 20) -> pd.DataFrame:
    df = df.copy()
    end = min(start + length, len(df))
    if kind == "fdi":
        df.loc[start:end, "frequency_hz"] += np.random.choice([1, -1]) * np.random.uniform(0.4, 1.0)
        df.loc[start:end, "voltage_v"] += np.random.uniform(-30, 30)
    elif kind == "replay":
        # repeat an earlier identical window verbatim (real physical noise wouldn't repeat exactly)
        src = df.iloc[max(0, start - 50):max(0, start - 50) + (end - start)]
        df.loc[start:end - 1, ["frequency_hz", "voltage_v"]] = src[["frequency_hz", "voltage_v"]].values
    elif kind == "dos":
        # command flood: timestamps collapse to near-simultaneous
        df.loc[start:end, "command_ts"] = df["timestamp"].iloc[start]
    elif kind == "unauth_command":
        df.loc[start:end, "auth_valid"] = False
    return df


def evaluate(detector: GridAnomalyDetector, df: pd.DataFrame, attack_windows: list) -> dict:
    """
    Reports overall precision/recall AND a per-attack-category breakdown.
    The breakdown matters more than the aggregate number here: this Isolation
    Forest stage is a *point*-anomaly detector, so it is expected to catch
    single-sample deviations (FDI / spoofed readings) well, and to miss
    *sequence*-pattern attacks (replay, slow-drift DoS) that look normal at
    any single instant but wrong over a window — that gap is exactly why the
    architecture specifies a second LSTM-autoencoder stage (see module
    docstring) rather than shipping Isolation Forest alone.
    """
    y_true, y_pred, latencies = [], [], []
    per_category_hits = {}
    for i in range(15, len(df)):
        window = df.iloc[max(0, i - 10):i + 1]
        t0 = time.perf_counter()
        result = detector.classify(window)
        latencies.append((time.perf_counter() - t0) * 1000)  # ms

        matching = [k for (s, e, k) in attack_windows if s <= i <= e]
        is_attack_gt = len(matching) > 0
        y_true.append(is_attack_gt)
        y_pred.append(result.is_anomaly)
        if is_attack_gt:
            k = matching[0]
            per_category_hits.setdefault(k, {"total": 0, "caught": 0})
            per_category_hits[k]["total"] += 1
            if result.is_anomaly:
                per_category_hits[k]["caught"] += 1

    y_true, y_pred = np.array(y_true), np.array(y_pred)
    tp = int(((y_true) & (y_pred)).sum())
    fp = int(((~y_true) & (y_pred)).sum())
    fn = int(((y_true) & (~y_pred)).sum())
    precision = tp / (tp + fp) if (tp + fp) else 0
    recall = tp / (tp + fn) if (tp + fn) else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

    category_recall = {
        k: round(v["caught"] / v["total"], 3) for k, v in per_category_hits.items()
    }

    return {
        "overall": {
            "precision": round(precision, 3),
            "recall": round(recall, 3),
            "f1": round(f1, 3),
            "false_positive_rate": round(fp / max(1, (~y_true).sum()), 4),
            "mean_scoring_latency_ms": round(float(np.mean(latencies)), 2),
        },
        "recall_by_attack_category": category_recall,
        "note": (
            "Point-anomaly stage (Isolation Forest) is strong on 'fdi' (single-sample "
            "deviation) and weak on 'replay'/'dos' (sequence-pattern attacks) by design. "
            "Recall on those categories is expected to improve substantially once the "
            "LSTM sequence-autoencoder stage is added — see README for the two-stage plan."
        ),
    }


if __name__ == "__main__":
    print("Generating baseline (normal operation) telemetry...")
    baseline = generate_baseline(hours=2)

    print("Training Isolation Forest on baseline only (unsupervised)...")
    # calibrate_percentile controls the precision/recall trade-off: higher = fewer
    # false positives but slower to catch subtle attacks. 97th percentile is a
    # reasonable starting point for a control-room deployment; tune per site.
    detector = GridAnomalyDetector(contamination=0.02).fit(baseline, calibrate_percentile=97.0)
    detector.save("models/isolation_forest.joblib")

    print("Building evaluation set with injected attacks...")
    eval_df = generate_baseline(hours=1)
    attack_windows = []
    for kind, start in [("fdi", 300), ("replay", 900), ("dos", 1800), ("unauth_command", 2600)]:
        eval_df = inject_attack(eval_df, kind, start, length=25)
        attack_windows.append((start, start + 25, kind))

    report = evaluate(detector, eval_df, attack_windows)
    print(json.dumps(report, indent=2))

    with open("evaluation_report.json", "w") as f:
        json.dump(report, f, indent=2)
