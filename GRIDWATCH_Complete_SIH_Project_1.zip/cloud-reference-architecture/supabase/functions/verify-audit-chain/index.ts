// Supabase Edge Function: verify-audit-chain
// Recomputes the SHA-256 hash chain over the entire audit_log table and reports
// the first point of divergence, if any. Used by the dashboard's "Verify Integrity" action
// and can be run on a schedule (pg_cron / external scheduler) for continuous assurance.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

async function sha256Hex(input: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  const { data: rows, error } = await supabase
    .from("audit_log")
    .select("id, actor, action, metadata, prev_hash, entry_hash")
    .order("id", { ascending: true });

  if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });

  let expectedPrev = "0".repeat(64);
  for (const row of rows) {
    if (row.prev_hash !== expectedPrev) {
      return new Response(
        JSON.stringify({
          ok: false,
          brokenAt: row.id,
          reason: "prev_hash does not match preceding entry's stored hash — chain link broken",
        }),
        { status: 200 }
      );
    }
    const recomputed = await sha256Hex(row.actor + row.action + JSON.stringify(row.metadata) + row.prev_hash);
    if (recomputed !== row.entry_hash) {
      return new Response(
        JSON.stringify({
          ok: false,
          brokenAt: row.id,
          reason: "recomputed hash does not match stored hash — row content was modified",
        }),
        { status: 200 }
      );
    }
    expectedPrev = row.entry_hash;
  }

  return new Response(JSON.stringify({ ok: true, entriesVerified: rows.length }), { status: 200 });
});
