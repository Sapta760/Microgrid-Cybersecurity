// Supabase Edge Function: rbac-guard
// Central permission check called by every state-changing function (config change,
// user management, patch deployment, alert acknowledgement) before the action runs.
// Denied attempts are still written to the audit log — visibility into blocked
// actions is itself a security signal.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

type Permission = "can_view" | "can_ack" | "can_config" | "can_patch" | "can_manage_users" | "can_view_audit";

async function sha256Hex(input: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function appendAuditLog(actor: string, action: string, metadata: Record<string, unknown>) {
  const { data: last } = await supabase
    .from("audit_log")
    .select("entry_hash")
    .order("id", { ascending: false })
    .limit(1)
    .maybeSingle();
  const prevHash = last?.entry_hash ?? "0".repeat(64);
  const entryHash = await sha256Hex(actor + action + JSON.stringify(metadata) + prevHash);
  await supabase.from("audit_log").insert({ actor, action, metadata, prev_hash: prevHash, entry_hash: entryHash });
}

export async function requirePermission(jwt: string, permission: Permission, actionLabel: string) {
  const { data: userRes } = await supabase.auth.getUser(jwt);
  if (!userRes?.user) return { ok: false, status: 401, reason: "invalid session" };

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", userRes.user.id)
    .maybeSingle();
  if (!profile) return { ok: false, status: 403, reason: "no profile" };

  const { data: perms } = await supabase
    .from("role_permissions")
    .select("*")
    .eq("role", profile.role)
    .maybeSingle();

  const allowed = !!perms?.[permission];

  if (!allowed) {
    await appendAuditLog(userRes.user.id, `DENIED: ${actionLabel} (role: ${profile.role})`, { permission });
    return { ok: false, status: 403, reason: `role '${profile.role}' lacks permission '${permission}'` };
  }
  return { ok: true, userId: userRes.user.id, role: profile.role };
}

// Example usage inside another edge function:
//
//   const jwt = req.headers.get("authorization")?.replace("Bearer ", "") ?? "";
//   const check = await requirePermission(jwt, "can_patch", "deploy patch v2.4.0");
//   if (!check.ok) return new Response(JSON.stringify({ error: check.reason }), { status: check.status });
