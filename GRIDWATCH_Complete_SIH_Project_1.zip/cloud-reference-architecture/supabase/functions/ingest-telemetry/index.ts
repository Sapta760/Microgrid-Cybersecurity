// Supabase Edge Function: ingest-telemetry
// Receives AES-256-GCM encrypted telemetry frames from field devices (over TLS 1.3),
// verifies device certificate binding, decrypts, scores for anomalies, and writes
// to the database + hash-chained audit log.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabase = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

// Master key for device-channel AES-256-GCM (in production: per-device key from a KMS/HSM,
// rotated on schedule — this is the single shared secret for demo simplicity).
const MASTER_KEY_HEX = Deno.env.get("TELEMETRY_AES_KEY")!;

async function importKey(hex: string) {
  const raw = new Uint8Array(hex.match(/.{1,2}/g)!.map((b) => parseInt(b, 16)));
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["decrypt"]);
}

async function decryptFrame(nonceB64: string, cipherB64: string, tagB64: string) {
  const key = await importKey(MASTER_KEY_HEX);
  const nonce = Uint8Array.from(atob(nonceB64), (c) => c.charCodeAt(0));
  const cipher = Uint8Array.from(atob(cipherB64), (c) => c.charCodeAt(0));
  const tag = Uint8Array.from(atob(tagB64), (c) => c.charCodeAt(0));
  // Web Crypto expects ciphertext + tag concatenated
  const combined = new Uint8Array(cipher.length + tag.length);
  combined.set(cipher, 0);
  combined.set(tag, cipher.length);
  const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv: nonce }, key, combined);
  return JSON.parse(new TextDecoder().decode(plainBuf));
}

async function sha256Hex(input: string) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(input));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

// Lightweight statistical anomaly score (mirrors the heavier offline Isolation Forest —
// see ai-engine/anomaly_detector.py — this is the fast inline first-pass filter).
function quickAnomalyScore(sample: { frequency_hz: number; voltage_v: number }) {
  const freqDev = Math.abs(sample.frequency_hz - 50.0) / 0.5; // normalized to expected band
  const voltDev = Math.abs(sample.voltage_v - 230.0) / 20.0;
  const score = Math.min(1, Math.max(freqDev, voltDev));
  return score;
}

async function appendAuditLog(actor: string, action: string, metadata: Record<string, unknown>) {
  const { data: last } = await supabase
    .from("audit_log")
    .select("entry_hash")
    .order("id", { ascending: false })
    .limit(1)
    .maybeSingle();
  const prevHash = last?.entry_hash ?? "0".repeat(64);
  const payload = actor + action + JSON.stringify(metadata) + prevHash;
  const entryHash = await sha256Hex(payload);
  await supabase.from("audit_log").insert({
    actor,
    action,
    metadata,
    prev_hash: prevHash,
    entry_hash: entryHash,
  });
}

Deno.serve(async (req) => {
  try {
    // 1. Verify caller presented a valid device client certificate (enforced at the
    //    Supabase/API-gateway TLS layer; here we check the forwarded cert fingerprint header).
    const certFingerprint = req.headers.get("x-client-cert-fingerprint");
    const deviceId = req.headers.get("x-device-id");
    if (!certFingerprint || !deviceId) {
      return new Response(JSON.stringify({ error: "missing mutual-TLS identity" }), { status: 401 });
    }

    const { data: device } = await supabase.from("devices").select("*").eq("id", deviceId).maybeSingle();
    if (!device || device.cert_serial !== certFingerprint) {
      await appendAuditLog(deviceId, "REJECTED: certificate mismatch on telemetry ingest", { certFingerprint });
      return new Response(JSON.stringify({ error: "certificate does not match registered device" }), { status: 403 });
    }
    if (device.status === "isolated") {
      return new Response(JSON.stringify({ error: "device is isolated — telemetry rejected" }), { status: 403 });
    }

    // 2. Decrypt payload
    const body = await req.json(); // { nonce, ciphertext, tag } all base64
    const sample = await decryptFrame(body.nonce, body.ciphertext, body.tag);

    // 3. Score for anomaly (fast path)
    const score = quickAnomalyScore(sample);
    const THRESHOLD = 0.65;

    // 4. Store telemetry (ciphertext retained at rest too, for forensics)
    await supabase.from("telemetry").insert({
      device_id: deviceId,
      frequency_hz: sample.frequency_hz,
      voltage_v: sample.voltage_v,
      power_kw: sample.power_kw ?? null,
      raw_payload_enc: body.ciphertext,
      auth_tag: body.tag,
      nonce: body.nonce,
    });

    // 5. If anomalous, raise alert + auto-isolate + log
    if (score >= THRESHOLD) {
      await supabase.from("alerts").insert({
        device_id: deviceId,
        severity: score > 0.85 ? "high" : "medium",
        category: "fdi",
        anomaly_score: score,
        description: `Telemetry deviated from expected band (freq=${sample.frequency_hz}Hz, volt=${sample.voltage_v}V)`,
      });
      await supabase.from("devices").update({ status: "isolated" }).eq("id", deviceId);
      await appendAuditLog("ids-engine", `Auto-isolated ${deviceId} — anomaly score ${score.toFixed(2)}`, { score, sample });
      return new Response(JSON.stringify({ status: "isolated", score }), { status: 200 });
    }

    await supabase.from("devices").update({ last_seen: new Date().toISOString() }).eq("id", deviceId);
    return new Response(JSON.stringify({ status: "accepted", score }), { status: 200 });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});
