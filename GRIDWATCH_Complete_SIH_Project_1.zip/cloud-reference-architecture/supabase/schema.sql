-- ============================================================
-- GRIDWATCH: Cybersecurity-Enabled Smart Controller
-- Supabase schema for grid-connected microgrid security platform
-- ============================================================

-- Extensions
create extension if not exists "pgcrypto";

-- ---------- ROLES & ACCESS CONTROL ----------
create type user_role as enum ('admin', 'engineer', 'operator', 'auditor');

create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role user_role not null default 'operator',
  cert_fingerprint text,           -- mTLS client cert fingerprint bound to this identity
  created_at timestamptz default now(),
  last_login timestamptz
);

-- Row Level Security: users only ever see what their role allows
alter table profiles enable row level security;
create policy "profiles_self_read" on profiles for select using (auth.uid() = id);

-- Permission matrix enforced in edge functions (rbac-guard) + mirrored here for reference
create table role_permissions (
  role user_role primary key,
  can_view boolean default true,
  can_ack boolean default false,
  can_config boolean default false,
  can_patch boolean default false,
  can_manage_users boolean default false,
  can_view_audit boolean default false
);
insert into role_permissions values
  ('admin',    true, true, true, true, true, true),
  ('engineer', true, true, true, true, false, false),
  ('operator', true, true, false, false, false, false),
  ('auditor',  true, false, false, false, false, true);

-- ---------- MICROGRID DEVICES ----------
create table devices (
  id text primary key,                     -- e.g. 'DER-01'
  name text not null,
  device_type text not null,               -- Solar PV / Storage / Wind / Metering / Switchgear
  protocol text not null,                  -- IEC 61850 / DNP3 / Modbus TCP
  firmware_version text not null,
  cert_serial text not null,               -- issued client cert for mutual TLS
  cert_expiry timestamptz not null,
  status text not null default 'secure',   -- secure | isolated | offline
  last_seen timestamptz default now()
);

-- ---------- TELEMETRY (encrypted at rest via pgcrypto, TLS in transit) ----------
create table telemetry (
  id bigint generated always as identity primary key,
  device_id text references devices(id),
  ts timestamptz default now(),
  frequency_hz numeric(6,3),
  voltage_v numeric(6,2),
  power_kw numeric(8,2),
  raw_payload_enc bytea,                   -- AES-256-GCM ciphertext of full raw frame
  auth_tag bytea,                          -- GCM authentication tag (integrity check)
  nonce bytea
);
create index idx_telemetry_device_ts on telemetry(device_id, ts desc);

-- ---------- IDS / ALERTS ----------
create table alerts (
  id bigint generated always as identity primary key,
  device_id text references devices(id),
  severity text not null,                  -- low | medium | high
  category text not null,                  -- fdi | replay | dos | unauth_command | mitm
  anomaly_score numeric(4,3),
  description text,
  acknowledged boolean default false,
  acknowledged_by uuid references profiles(id),
  created_at timestamptz default now()
);

-- ---------- IMMUTABLE AUDIT LOG (hash chain) ----------
create table audit_log (
  id bigint generated always as identity primary key,
  actor text not null,                     -- user id, device id, or 'system'
  action text not null,
  metadata jsonb,
  prev_hash text not null,
  entry_hash text not null,                -- sha256(id || actor || action || metadata || prev_hash)
  created_at timestamptz default now()
);
-- Prevent UPDATE/DELETE at the DB level -- audit rows are append-only.
create rule audit_log_no_update as on update to audit_log do instead nothing;
create rule audit_log_no_delete as on delete to audit_log do instead nothing;

-- ---------- PATCH MANAGEMENT ----------
create table patches (
  id bigint generated always as identity primary key,
  version text not null,
  cve_reference text,
  description text,
  signature text not null,                 -- RSA-2048/ECDSA signature over the patch binary hash
  binary_hash text not null,               -- SHA-256 of the patch payload
  signed_by text not null,                 -- issuing CA / key id
  status text default 'pending',           -- pending | canary | rolling | complete | rolled_back
  created_at timestamptz default now()
);

create table patch_deployments (
  id bigint generated always as identity primary key,
  patch_id bigint references patches(id),
  device_id text references devices(id),
  status text default 'pending',           -- pending | verifying | applied | failed | rolled_back
  applied_at timestamptz
);

-- ---------- Helper: get current user's role permissions ----------
create or replace function current_user_permissions()
returns table (can_view boolean, can_ack boolean, can_config boolean, can_patch boolean, can_manage_users boolean, can_view_audit boolean)
language sql security definer as $$
  select rp.can_view, rp.can_ack, rp.can_config, rp.can_patch, rp.can_manage_users, rp.can_view_audit
  from profiles p join role_permissions rp on rp.role = p.role
  where p.id = auth.uid();
$$;
