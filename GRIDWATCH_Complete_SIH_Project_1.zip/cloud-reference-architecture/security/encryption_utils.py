"""
GRIDWATCH — Cryptographic utilities.

Two independent mechanisms, used for different threat models:

1. AES-256-GCM  — secures the live telemetry/control channel between the
   smart controller and field devices (confidentiality + integrity via the
   GCM authentication tag; catches both eavesdropping and tampering).
   Runs over TLS 1.3 as a second, application-layer encryption of the
   payload itself — defense in depth in case the TLS session is
   ever downgraded or terminated early at a proxy.

2. RSA-2048 signing — secures the patch/firmware supply chain. A patch is
   only ever applied if its signature verifies against the trusted CA's
   public key, preventing a compromised or spoofed update server from
   pushing malicious firmware to grid devices.

Requires: pip install cryptography
"""

import os
import json
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import hashes, serialization


# ---------------------------------------------------------------------
# 1. Telemetry channel encryption — AES-256-GCM
# ---------------------------------------------------------------------
class TelemetryCipher:
    def __init__(self, key: bytes | None = None):
        self.key = key or AESGCM.generate_key(bit_length=256)
        self.aead = AESGCM(self.key)

    def encrypt(self, payload: dict) -> dict:
        """Returns {nonce, ciphertext, tag} all base64-ready bytes, tag split out
        for storage/inspection even though AESGCM appends it internally."""
        nonce = os.urandom(12)  # 96-bit nonce, required unique per key
        plaintext = json.dumps(payload).encode()
        ct_and_tag = self.aead.encrypt(nonce, plaintext, associated_data=None)
        ciphertext, tag = ct_and_tag[:-16], ct_and_tag[-16:]
        return {"nonce": nonce, "ciphertext": ciphertext, "tag": tag}

    def decrypt(self, nonce: bytes, ciphertext: bytes, tag: bytes) -> dict:
        combined = ciphertext + tag
        plaintext = self.aead.decrypt(nonce, combined, associated_data=None)
        return json.loads(plaintext.decode())


# ---------------------------------------------------------------------
# 2. Patch signing / verification — RSA-2048 + SHA-256
# ---------------------------------------------------------------------
class PatchSigningAuthority:
    """Represents the trusted CA that signs approved firmware/patches.
    Private key lives in an HSM/secrets manager in production — never on
    the controller itself."""

    def __init__(self):
        self.private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.public_key = self.private_key.public_key()

    def sign_patch(self, patch_bytes: bytes) -> bytes:
        return self.private_key.sign(
            patch_bytes,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )

    def export_public_key_pem(self) -> bytes:
        return self.public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )


class ControllerPatchVerifier:
    """Runs on the smart controller. Only holds the CA's public key —
    can verify signatures but can never forge one."""

    def __init__(self, ca_public_key_pem: bytes):
        self.public_key = serialization.load_pem_public_key(ca_public_key_pem)

    def verify(self, patch_bytes: bytes, signature: bytes) -> bool:
        try:
            self.public_key.verify(
                signature,
                patch_bytes,
                padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                hashes.SHA256(),
            )
            return True
        except Exception:
            return False


if __name__ == "__main__":
    # --- Telemetry channel demo ---
    cipher = TelemetryCipher()
    frame = {"device": "DER-01", "frequency_hz": 49.998, "voltage_v": 229.7}
    enc = cipher.encrypt(frame)
    decrypted = cipher.decrypt(enc["nonce"], enc["ciphertext"], enc["tag"])
    print("Telemetry round-trip OK:", decrypted == frame)

    # Tamper test: flip one byte of ciphertext -> GCM tag check must fail
    tampered = bytearray(enc["ciphertext"]); tampered[0] ^= 0xFF
    try:
        cipher.decrypt(enc["nonce"], bytes(tampered), enc["tag"])
        print("Tamper NOT detected (unexpected)")
    except Exception:
        print("Tamper detected correctly — GCM authentication tag rejected modified ciphertext")

    # --- Patch signing demo ---
    ca = PatchSigningAuthority()
    verifier = ControllerPatchVerifier(ca.export_public_key_pem())

    patch = b"firmware-v2.4.0-binary-contents..."
    sig = ca.sign_patch(patch)
    print("Legitimate patch verifies:", verifier.verify(patch, sig))

    forged_patch = b"firmware-v2.4.0-MALICIOUS-PAYLOAD"
    print("Forged patch verifies (should be False):", verifier.verify(forged_patch, sig))
