# GRIDWATCH — Cybersecurity-Enabled Smart Controller for Grid-Connected Microgrids

## Read this first: about the files you may have seen elsewhere

If you (or a teammate) have a copy of `QUICK_START.md` / `FILE_INDEX.md` /
`IMPLEMENTATION_COMPLETE.md` describing 7 modules — `secure-channel.js`,
`advanced-ids-ips.js`, `advanced-rbac.js`, `blockchain-audit-logger.js`,
`multi-protocol-gateway.js`, `advanced-patch-manager.js`,
`compliance-reporter.js` — **those files do not exist in this project.**
Only documentation *claiming* they were built ever surfaced; the actual code
was never produced or tested. Do not include those `.md` files in your
submission or cite those line/endpoint counts to judges — if asked to show
the code, there isn't any, and that's a far worse position than not having
claimed it. This README describes only what is actually in this zip, and
everything described below has been run and tested (see "How I verified
this" at the bottom of each section).

## What's actually in this zip

```
gridwatch-node-app/     ← The real, working full-stack app. Zero install step.
cloud-reference-architecture/ ← Supabase/Python reference implementation
                                  (schema, edge functions, offline ML
                                  training pipeline) — not required to run
                                  the demo, kept as the production-scale answer.
```

## Run it (30 seconds, no install)

```bash
cd gridwatch-node-app/backend
node server.js
```
Open **http://localhost:8787**. No `npm install`, no build step, no env vars.

## What's new in this version

### 1. Encryption you can actually *see* — the "Security Internals" page

This was the main gap flagged: the app had real AES-256-GCM and RSA-2048
running, but nothing on screen showed it happening. The new **Security
Internals** page (`backend/modules/crypto-lab.js` + a dedicated frontend
page) runs the real primitives live and streams back every intermediate
value:

- **AES-256-GCM**: click "Run Live Encryption" — you see the actual
  plaintext telemetry frame, the randomly generated 96-bit nonce, the
  256-bit key (shown in full, for teaching purposes — never do this in
  production), the resulting ciphertext in hex, the GCM authentication tag,
  the decrypted round-trip, and a live tamper test where one flipped byte
  causes decryption to fail outright.
- **RSA-2048/PSS**: click "Run Live Signing" — you see the patch payload,
  its SHA-256 digest, the actual signature bytes, a successful verification
  against the CA public key, and a forged-payload verification that
  correctly fails.
- **SHA-256 hash chain**: shows the *exact string* that gets hashed for the
  next audit entry (`actor|action|metadata|prevHash`), not just the output —
  so "how is this tamper-evident" has a concrete, inspectable answer.

**How I verified this:** ran all three endpoints via curl against the live
server and inspected the JSON responses; tamper detection and forged-
signature rejection both confirmed working before this went in the zip.

### 2. A real block-structured chain, not just a flat hash-chain

`backend/modules/blockchain-lite.js` batches every 4 audit entries into a
block, computes a genuine Merkle root over them, and chains block headers
together (`block.prevBlockHash -> previous block.blockHash`). This is
visible on the **Audit Chain** page below the flat log, with "Seal Pending
Entries," "Tamper a Sealed Block," and "Verify Block Chain" controls.

**Why no consensus mechanism / no distributed nodes:** there is one trusted
controller in this architecture, so distributed consensus buys nothing —
adding it would be exactly the kind of buzzword-stacking a judge with a
security background will call out. What actually matters for an audit trail
— tamper-evidence and independently-checkable proofs — is real here: Merkle
proofs (`getProofFor`) let you verify a single transaction belongs to a
block without needing the whole block.

**How I verified this — including a bug I caught and fixed:** my first
version of `verifyChain()` recomputed the Merkle root from each transaction's
*stored* hash field, so a tamper that edited a transaction's content but
left its hash field untouched went undetected — it returned `ok:true` after
a tamper, which would have been an embarrassing thing to demo live. Fixed it
to recompute each transaction's hash from its actual content first; re-ran
the same tamper test and it now correctly reports
`{"ok":false,"brokenAtBlock":0,"brokenAtTx":0,"reason":"transaction 0
content does not match its stored hash — this entry was directly edited"}`.

### 3. Detector thresholds grounded in published research, not guessed numbers

`ids-engine.js` now cites where its deviation bands come from: frequency
deviation under 0.01 p.u. and voltage deviation under 0.05 p.u. of nominal
are standard operational bounds for inverter-based microgrids (Zhang et al.,
arXiv:2206.11407; corroborated with 0.95–1.05 p.u. voltage limits in
"Impact Assessment of Cyberattacks in Inverter-Based Microgrids,"
arXiv:2504.05592). On a 50Hz/230V system that's ~0.5Hz and ~11.5V — this is
what the calibration is built around, with a citation instead of an
unexplained magic number. This is *not* a live real-time data feed (no
network egress is available to stream one into this sandbox) — it's
published-research-grounded simulation parameters, which is an honest and
defensible middle ground between pure synthetic noise and a claim of live
grid data this environment can't actually deliver.

### 4. Visual overhaul

- Particle network background on the login screen (canvas, connects nearby
  points with fading lines — cheap, real-time, no library)
- Screen-wide red vignette + subtle jitter while an attack is active,
  clearing automatically once mitigated
- Animated dashed data-flow lines on the topology diagram
- New block-chain visualization cards on the Audit page

## Architecture

```
Digital Twin (6 simulated devices)
   │ publishes telemetry every 1s
   ▼
MQTT-style Bus (topic pub/sub)
   │ ◄── Attack Simulator injects here
   ▼
AI Detection Engine (statistical + XAI) ──► Crypto Lab (on-demand, visible)
   │ publishes alerts
   ▼
Response & Audit Engine (isolates + hash-chains) ──► Blockchain-lite (blocks + Merkle)
   │ isolation command flows back to twin — closed loop
   ▼
SOC Dashboard (vanilla JS + SSE)
```

## Honest scope notes (have these ready for judge Q&A)

- Detector is a transparent statistical model (online mean/std per device),
  not a trained ML model — deliberate, since the explanation IS the
  computation. `cloud-reference-architecture/ai-engine/` has a real trained
  Isolation Forest with an honest evaluation report (100% recall on FDI,
  documented weak spot on replay/DoS — the stated reason for an LSTM stage
  next).
- mTLS/device certificates are not implemented — code comments mark where
  they'd plug in.
- Session tokens regenerate on server restart (in-memory HMAC secret).
- Not load-tested or security-audited — a working hackathon prototype
  demonstrating the full closed loop, not a certified deployment.
- No live real-time grid data feed (sandbox has no network egress for
  streaming); parameters are grounded in cited published research instead.

## Standards referenced

IEC 62351, IEC 61850, NIST SP 800-82, DNP3 Secure Authentication v5.
