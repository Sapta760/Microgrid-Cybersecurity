/**
 * app.js — GRIDWATCH SOC dashboard. Vanilla JS, no framework, no build step.
 * Talks to the real backend (server.js) over REST + Server-Sent Events —
 * this is not a client-side simulation, every number on screen came from
 * the Node backend's digital twin / IDS engine / audit log.
 */

const ROLES = {
  admin:    { label: 'Administrator', color: 'var(--violet)' },
  engineer: { label: 'Engineer',      color: 'var(--cyan)' },
  operator: { label: 'Operator',      color: 'var(--green)' },
  auditor:  { label: 'Auditor',       color: 'var(--amber)' },
};

const DEVICE_POS = {
  'DER-01':  { x: 15, y: 30 },
  'DER-02':  { x: 85, y: 30 },
  'BESS-01': { x: 15, y: 65 },
  'WT-01':   { x: 85, y: 65 },
  'MTR-01':  { x: 50, y: 20 },
  'BRK-01':  { x: 50, y: 78 },
};

const state = {
  session: null,           // { token, user, role, perms }
  page: 'overview',
  devices: [],
  telemetryHistory: {},    // deviceId -> [{ts, frequency, voltage}]
  latestDetection: {},     // deviceId -> detection result
  alerts: [],
  auditLive: [],
  attack: null,
  patch: null,
  auditIntegrity: null,
  gridStatus: 'normal',    // normal | attack | mitigating
  es: null,
};

// ---------------- API helpers ----------------
async function api(path, opts = {}) {
  const headers = opts.headers || {};
  if (state.session) headers['Authorization'] = 'Bearer ' + state.session.token;
  if (opts.body) headers['Content-Type'] = 'application/json';
  const res = await fetch(path, { ...opts, headers, body: opts.body ? JSON.stringify(opts.body) : undefined });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

// ---------------- Root render ----------------
const root = document.getElementById('app');

function render() {
  if (!state.session) return renderLogin();
  renderShell();
}

// ================================================================
// LOGIN
// ================================================================
let selectedRole = 'admin';

function renderLogin() {
  root.innerHTML = `
    <div class="login-screen">
      <canvas id="particleCanvas"></canvas>
      <div class="panel login-card" id="loginCard">
        <div class="login-badge">
          <span class="dot dot-pulse" style="background:var(--cyan)"></span>
          <span class="mono" style="font-size:11px; letter-spacing:.1em; color:var(--text-2)">GRIDWATCH SECURE CONSOLE</span>
        </div>
        <div class="login-title">Sign in</div>
        <div class="login-desc">Session token issued and logged to the audit chain on authentication.</div>
        <label class="field-label">Operator ID</label>
        <input id="userInput" class="field-input" placeholder="e.g. rgupta" />
        <label class="field-label">Access role</label>
        <div class="role-grid" id="roleGrid">
          ${Object.entries(ROLES).map(([key, def]) => `
            <button type="button" class="role-option ${key === selectedRole ? 'selected' : ''}" data-role="${key}"
              style="border-color:${key === selectedRole ? def.color : 'var(--line)'}">
              <span class="role-dot" style="background:${def.color}"></span>${def.label}
            </button>
          `).join('')}
        </div>
        <button id="loginBtn" class="btn btn-solid-cyan" style="width:100%; padding:12px">Authenticate &rarr;</button>
        <div class="login-footer-note">AES-256-GCM channel · RBAC session tokens · signed audit trail</div>
      </div>
    </div>
  `;

  initParticles();
  document.querySelectorAll('.role-option').forEach((btn) => {
    btn.addEventListener('click', () => { selectedRole = btn.dataset.role; renderLogin(); });
  });
  document.getElementById('loginBtn').addEventListener('click', doLogin);
  document.getElementById('userInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') doLogin(); });
}

let particleRAF = null;
function initParticles() {
  const canvas = document.getElementById('particleCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  function resize() { canvas.width = canvas.clientWidth * devicePixelRatio; canvas.height = canvas.clientHeight * devicePixelRatio; }
  resize();
  window.addEventListener('resize', resize);

  const N = 55;
  const particles = Array.from({ length: N }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    vx: (Math.random() - 0.5) * 0.25 * devicePixelRatio,
    vy: (Math.random() - 0.5) * 0.25 * devicePixelRatio,
    r: (Math.random() * 1.5 + 0.5) * devicePixelRatio,
  }));

  if (particleRAF) cancelAnimationFrame(particleRAF);
  function draw() {
    if (!document.getElementById('particleCanvas')) return; // page navigated away
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (const p of particles) {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(51,199,214,0.5)';
      ctx.fill();
    }
    // draw connecting lines between nearby particles — the "network" feel
    for (let i = 0; i < N; i++) {
      for (let j = i + 1; j < N; j++) {
        const dx = particles[i].x - particles[j].x, dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const maxDist = 130 * devicePixelRatio;
        if (dist < maxDist) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(51,199,214,${0.12 * (1 - dist / maxDist)})`;
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      }
    }
    particleRAF = requestAnimationFrame(draw);
  }
  draw();
}

async function doLogin() {
  const user = document.getElementById('userInput').value.trim();
  if (!user) {
    const card = document.getElementById('loginCard');
    card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake');
    return;
  }
  try {
    const data = await api('/api/login', { method: 'POST', body: { user, role: selectedRole } });
    state.session = data;
    await bootstrap();
  } catch (err) {
    alert('Login failed: ' + err.message);
  }
}

// ================================================================
// SHELL + SSE
// ================================================================
async function bootstrap() {
  const s = await api('/api/state');
  state.devices = s.devices;
  state.patch = s.patch;
  state.auditIntegrity = s.auditIntegrity;
  state.attack = s.attack;
  connectStream();
  render();
}

function connectStream() {
  if (state.es) state.es.close();
  const es = new EventSource('/api/stream');
  state.es = es;

  es.addEventListener('telemetry', (e) => {
    const d = JSON.parse(e.data);
    const hist = (state.telemetryHistory[d.deviceId] ||= []);
    hist.push(d);
    if (hist.length > 40) hist.shift();
    if (state.page === 'overview') updateOverviewLive();
  });

  es.addEventListener('detection', (e) => {
    const d = JSON.parse(e.data);
    state.latestDetection[d.deviceId] = d;
    if (state.page === 'ids') renderIdsPanels();
  });

  es.addEventListener('alert', (e) => {
    const d = JSON.parse(e.data);
    state.alerts.unshift({ ...d, at: new Date().toLocaleTimeString() });
    state.gridStatus = 'attack';
    setTimeout(() => { if (state.gridStatus === 'attack') { state.gridStatus = 'mitigating'; updatePulseState(); } }, 1500);
    updateAlertsFeed();
    updatePulseState();
  });

  es.addEventListener('command', (e) => {
    const d = JSON.parse(e.data);
    if (d.action === 'isolate') updateDeviceStatus(d.topic.split('/')[1], 'isolated');
    if (d.action === 'restore') updateDeviceStatus(d.topic.split('/')[1], 'secure');
  });

  es.addEventListener('audit', (e) => {
    const entry = JSON.parse(e.data);
    state.auditLive.unshift(entry);
    if (state.page === 'audit') renderAuditRows();
  });

  es.addEventListener('attacksim', (e) => {
    const d = JSON.parse(e.data);
    state.attack = d.event === 'started' ? d : null;
    if (d.event === 'stopped') { state.gridStatus = 'normal'; updatePulseState(); }
    if (state.page === 'overview') renderOverviewAttackControls();
  });
}

function updateDeviceStatus(deviceId, status) {
  const dev = state.devices.find((d) => d.id === deviceId);
  if (dev) dev.status = status;
  if (state.page === 'topology') renderTopologyBody();
  if (state.page === 'overview') renderOverviewDeviceCount();
}

const NAV = [
  { id: 'overview', label: 'Overview', icon: '\u25c8' },
  { id: 'topology', label: 'Topology', icon: '\u2318' },
  { id: 'ids', label: 'Threat Detection', icon: '\u25b2' },
  { id: 'cryptolab', label: 'Security Internals', icon: '\u2b21' },
  { id: 'access', label: 'Access Control', icon: '\u26bf', need: 'users' },
  { id: 'audit', label: 'Audit Chain', icon: '\u2261', need: 'audit' },
  { id: 'patch', label: 'Patch Management', icon: '\u21ea', need: 'patch' },
];
const TITLES = {
  overview: 'Security Overview', topology: 'Microgrid Topology', ids: 'Threat Detection Engine',
  cryptolab: 'Security Internals — Live Cryptography', access: 'Access Control', audit: 'Audit Chain', patch: 'Patch Management',
};

function can(perm) { return state.session.perms.includes(perm); }

function renderShell() {
  const role = ROLES[state.session.role];
  root.innerHTML = `
    <div class="glitch-vignette" id="glitchOverlay"></div>
    <div class="sidebar">
      <div class="sidebar-header">
        <span class="dot dot-pulse" style="background:var(--cyan)"></span>
        <div>
          <div class="brand-name">GRIDWATCH</div>
          <div class="brand-sub">SMART CONTROLLER SEC.</div>
        </div>
      </div>
      <div class="nav" id="navList"></div>
      <div class="sidebar-footer">
        <div class="session-chip">
          <div class="avatar" style="background:${role.color}">${state.session.user.slice(0,2).toUpperCase()}</div>
          <div>
            <div class="session-name">${escapeHtml(state.session.user)}</div>
            <div class="session-role mono" style="color:${role.color}">${role.label}</div>
          </div>
        </div>
      </div>
    </div>
    <div class="main">
      <div class="topbar">
        <div>
          <div class="page-title">${TITLES[state.page]}</div>
          <div class="page-sub">Grid-connected microgrid · Live backend session · AES-256-GCM channel</div>
        </div>
        <div class="gap-8" style="align-items:center; display:flex">
          <div class="status-chip" id="statusChip"></div>
          <button class="btn" id="signOutBtn">Sign out</button>
        </div>
      </div>
      <div class="content" id="content"></div>
    </div>
  `;

  renderNav();
  updateStatusChip();
  document.getElementById('signOutBtn').addEventListener('click', () => {
    if (state.es) state.es.close();
    Object.assign(state, { session: null, page: 'overview', alerts: [], telemetryHistory: {}, latestDetection: {}, auditLive: [] });
    render();
  });

  renderPage();
}

function renderNav() {
  const nav = document.getElementById('navList');
  nav.innerHTML = NAV.map((item) => {
    const locked = item.need && !can(item.need);
    return `<div class="nav-item ${state.page === item.id ? 'active' : ''} ${locked ? 'disabled' : ''}" data-page="${item.id}">
      <span class="nav-icon">${item.icon}</span><span>${item.label}</span>
      ${locked ? '<span class="lock">&#128274;</span>' : ''}
    </div>`;
  }).join('');
  nav.querySelectorAll('.nav-item').forEach((el) => {
    el.addEventListener('click', () => {
      const page = el.dataset.page;
      const item = NAV.find((n) => n.id === page);
      if (item.need && !can(item.need)) return;
      state.page = page;
      renderShell();
    });
  });
}

function updateStatusChip() {
  const chip = document.getElementById('statusChip');
  if (!chip) return;
  const map = {
    normal: ['var(--green)', 'ALL SYSTEMS SECURE'],
    mitigating: ['var(--amber)', 'MITIGATING'],
    attack: ['var(--red)', 'THREAT ACTIVE'],
  };
  const [color, label] = map[state.gridStatus];
  chip.innerHTML = `<span class="dot dot-pulse" style="background:${color}"></span><span class="mono">${label}</span>`;
}

function renderPage() {
  const content = document.getElementById('content');
  if (state.page === 'overview') return renderOverview(content);
  if (state.page === 'topology') return renderTopology(content);
  if (state.page === 'ids') return renderIds(content);
  if (state.page === 'cryptolab') return renderCryptoLab(content);
  if (state.page === 'access') return renderAccess(content);
  if (state.page === 'audit') return renderAudit(content);
  if (state.page === 'patch') return renderPatch(content);
}

// ================================================================
// OVERVIEW PAGE
// ================================================================
let pulseCanvasCtx = null, pulsePhase = 0, pulseRAF = null;
let voltCanvasCtx = null;

function renderOverview(content) {
  content.innerHTML = `
    <div class="panel pulse-panel state-${state.gridStatus === 'attack' ? 'attack' : 'normal'}" id="pulsePanel">
      <div class="pulse-top">
        <div>
          <div class="section-label" style="margin-bottom:4px">GRID PULSE — LIVE FREQUENCY STABILITY</div>
          <div class="pulse-value mono" id="pulseFreqValue" style="color:var(--cyan)">50.000 Hz</div>
        </div>
        <div id="pulseBadge"></div>
      </div>
      <div class="pulse-canvas-wrap"><canvas id="pulseCanvas"></canvas></div>
      <div class="pulse-actions" id="attackControls"></div>
    </div>

    <div class="kpi-row" id="kpiRow"></div>

    <div class="grid-2">
      <div class="panel panel-pad">
        <div class="section-label">BUS VOLTAGE (V) — LIVE FROM BACKEND</div>
        <div style="height:220px"><canvas id="voltCanvas" style="width:100%; height:100%"></canvas></div>
      </div>
      <div class="panel panel-pad">
        <div class="section-label">LIVE ALERT FEED</div>
        <div class="feed" id="alertsFeed"></div>
      </div>
    </div>
  `;

  const pc = document.getElementById('pulseCanvas');
  pc.width = pc.clientWidth * devicePixelRatio; pc.height = pc.clientHeight * devicePixelRatio;
  pulseCanvasCtx = pc.getContext('2d');

  const vc = document.getElementById('voltCanvas');
  vc.width = vc.clientWidth * devicePixelRatio; vc.height = vc.clientHeight * devicePixelRatio;
  voltCanvasCtx = vc.getContext('2d');

  renderOverviewAttackControls();
  renderOverviewDeviceCount();
  updateAlertsFeed();
  updatePulseState();
  startPulseAnimation();
  drawVoltChart();
}

function renderOverviewAttackControls() {
  const el = document.getElementById('attackControls');
  if (!el) return;
  const active = state.attack;
  el.innerHTML = `
    <button class="btn ${active && active.type === 'fdi' ? 'btn-solid-red' : 'btn-outline-red'}" id="btnFdi">
      ${active && active.type === 'fdi' ? '\u25a0 Stop False-Data Injection' : '\u25b6 Simulate False-Data Injection'}
    </button>
    <button class="btn ${active && active.type === 'dos' ? 'btn-solid-red' : 'btn-outline-amber'}" id="btnDos">
      ${active && active.type === 'dos' ? '\u25a0 Stop DoS Flood' : '\u25b6 Simulate DoS Flood'}
    </button>
    <button class="btn ${active && active.type === 'replay' ? 'btn-solid-red' : 'btn-outline-cyan'}" id="btnReplay">
      ${active && active.type === 'replay' ? '\u25a0 Stop Replay Attack' : '\u25b6 Simulate Replay Attack'}
    </button>
  `;
  document.getElementById('btnFdi').onclick = () => toggleAttack('fdi', 'DER-01');
  document.getElementById('btnDos').onclick = () => toggleAttack('dos', 'WT-01');
  document.getElementById('btnReplay').onclick = () => toggleAttack('replay', 'BESS-01');
}

async function toggleAttack(type, deviceId) {
  if (state.attack && state.attack.type === type) {
    await api('/api/attack/stop', { method: 'POST' });
  } else {
    await api(`/api/attack/${type}`, { method: 'POST', body: { deviceId } });
  }
}

function renderOverviewDeviceCount() {
  const row = document.getElementById('kpiRow');
  if (!row) return;
  const isolated = state.devices.filter((d) => d.status === 'isolated').length;
  row.innerHTML = `
    ${kpiCard('Connected Devices', state.devices.length, isolated ? `${isolated} isolated` : 'All secure · mTLS', 'var(--cyan)')}
    ${kpiCard('Threats Detected', state.alerts.length, 'this session', 'var(--green)')}
    ${kpiCard('Audit Chain', state.auditIntegrity && state.auditIntegrity.ok ? 'VERIFIED' : '—', 'SHA-256 hash-linked', 'var(--green)')}
    ${kpiCard('Encryption', 'AES-256-GCM', 'RSA-2048 patch signing', 'var(--violet)')}
  `;
}
function kpiCard(label, value, sub, color) {
  return `<div class="panel kpi"><div class="kpi-label">${label}</div><div class="kpi-value mono" style="color:${color}">${value}</div><div class="kpi-sub">${sub}</div></div>`;
}

function updateOverviewLive() {
  const all = Object.values(state.telemetryHistory).flat();
  const last = all[all.length - 1];
  if (last) {
    const freqEl = document.getElementById('pulseFreqValue');
    if (freqEl) freqEl.textContent = last.frequency.toFixed(3) + ' Hz';
  }
  drawVoltChart();
}

function updatePulseState() {
  const panel = document.getElementById('pulsePanel');
  const badge = document.getElementById('pulseBadge');
  if (panel) panel.className = 'panel pulse-panel state-' + (state.gridStatus === 'attack' ? 'attack' : 'normal');
  if (badge) {
    if (state.gridStatus === 'attack') badge.innerHTML = badgeHtml('red', '\u26a0 ANOMALY DETECTED');
    else if (state.gridStatus === 'mitigating') badge.innerHTML = badgeHtml('amber', '\u25d0 MITIGATING');
    else badge.innerHTML = badgeHtml('green', '\u25cf SECURE / NOMINAL');
  }
  const overlay = document.getElementById('glitchOverlay');
  if (overlay) overlay.classList.toggle('active', state.gridStatus === 'attack');
  document.body.classList.toggle('attack-active', state.gridStatus === 'attack');
  updateStatusChip();
}
function badgeHtml(tone, text) { return `<span class="badge badge-${tone}">${text}</span>`; }

function startPulseAnimation() {
  if (pulseRAF) cancelAnimationFrame(pulseRAF);
  function draw() {
    if (!pulseCanvasCtx || state.page !== 'overview') { pulseRAF = requestAnimationFrame(draw); return; }
    const ctx = pulseCanvasCtx, canvas = ctx.canvas;
    const w = canvas.width, h = canvas.height, mid = h / 2;
    const attacking = state.gridStatus === 'attack';
    const mitigating = state.gridStatus === 'mitigating';
    const color = attacking ? '#E5484D' : mitigating ? '#F5A623' : '#33C7D6';
    const amp = attacking ? h * 0.42 : mitigating ? h * 0.22 : h * 0.13;
    const freq = attacking ? 0.055 : 0.035;
    const noise = attacking ? 0.55 : mitigating ? 0.15 : 0.03;
    pulsePhase += attacking ? 0.5 : 0.22;

    ctx.clearRect(0, 0, w, h);
    ctx.beginPath();
    for (let x = 0; x < w; x++) {
      const jitter = (Math.random() - 0.5) * noise * amp;
      const y = mid + Math.sin(x * freq + pulsePhase) * amp + jitter;
      x === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.strokeStyle = color; ctx.lineWidth = 2 * devicePixelRatio;
    ctx.shadowBlur = 12; ctx.shadowColor = color;
    ctx.stroke();
    pulseRAF = requestAnimationFrame(draw);
  }
  draw();
}

function drawVoltChart() {
  if (!voltCanvasCtx) return;
  const ctx = voltCanvasCtx, canvas = ctx.canvas;
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const all = Object.values(state.telemetryHistory).flat().sort((a, b) => a.ts - b.ts).slice(-60);
  if (all.length < 2) return;
  const volts = all.map((d) => d.voltage);
  const min = Math.min(...volts, 190), max = Math.max(...volts, 270);

  // grid lines
  ctx.strokeStyle = '#1A2740'; ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = (h / 4) * i;
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
  }

  ctx.beginPath();
  all.forEach((d, i) => {
    const x = (i / (all.length - 1)) * w;
    const y = h - ((d.voltage - min) / (max - min || 1)) * h;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });
  ctx.strokeStyle = '#33C7D6'; ctx.lineWidth = 2 * devicePixelRatio;
  ctx.stroke();

  // fill under curve
  ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath();
  const grad = ctx.createLinearGradient(0, 0, 0, h);
  grad.addColorStop(0, 'rgba(51,199,214,0.28)'); grad.addColorStop(1, 'rgba(51,199,214,0)');
  ctx.fillStyle = grad; ctx.fill();
}

function updateAlertsFeed() {
  const feed = document.getElementById('alertsFeed');
  if (!feed) return;
  if (!state.alerts.length) { feed.innerHTML = `<div class="feed-empty">No active alerts. System nominal.</div>`; return; }
  feed.innerHTML = state.alerts.slice(0, 10).map((a) => `
    <div class="feed-item sev-${a.score > 0.85 ? 'high' : 'med'}">
      <div class="feed-item-top">
        <span class="feed-item-title">${a.category.toUpperCase()} detected on ${a.deviceId}</span>
        <span class="feed-item-time mono">${a.at}</span>
      </div>
      <div class="feed-item-detail">Anomaly score ${a.score.toFixed(2)} — auto-isolation triggered</div>
    </div>
  `).join('');
  renderOverviewDeviceCount();
}

// ================================================================
// TOPOLOGY PAGE
// ================================================================
function renderTopology(content) {
  content.innerHTML = `
    <div class="panel panel-pad mb-16">
      <div class="section-label">MICROGRID TOPOLOGY — LIVE NODE STATUS</div>
      <div class="section-note">Protocol-agnostic adapter layer — new devices onboard via signed config, no core changes required.</div>
      <div class="topo-canvas" id="topoCanvas"></div>
    </div>
    <div class="panel panel-pad"><div id="topoTable"></div></div>
  `;
  renderTopologyBody();
}

function renderTopologyBody() {
  const canvas = document.getElementById('topoCanvas');
  const table = document.getElementById('topoTable');
  if (!canvas) return;

  const svgLines = state.devices.map((d) => {
    const p = DEVICE_POS[d.id];
    const bad = d.status === 'isolated';
    return `<line x1="50%" y1="92%" x2="${p.x}%" y2="${p.y}%" stroke="${bad ? '#E5484D' : '#22314A'}" stroke-width="1.5" ${bad ? 'stroke-dasharray="4 3"' : ''}/>`;
  }).join('');

  const nodeHtml = state.devices.map((d) => {
    const p = DEVICE_POS[d.id];
    const bad = d.status === 'isolated';
    return `<div class="topo-node" style="left:${p.x}%; top:${p.y}%">
      <div class="topo-node-box ${bad ? 'bad' : ''}">${bad ? '\u26a0' : d.type[0]}</div>
      <div class="topo-node-label" style="${bad ? 'color:var(--red)' : ''}">${d.id}</div>
    </div>`;
  }).join('');

  canvas.innerHTML = `
    <svg style="position:absolute; inset:0; width:100%; height:100%">${svgLines}</svg>
    ${nodeHtml}
    <div class="topo-node" style="left:50%; top:92%">
      <div class="topo-node-box ctrl">CTRL</div>
      <div class="topo-node-label" style="color:var(--cyan)">Smart Controller</div>
    </div>
  `;

  table.innerHTML = `
    <table>
      <thead><tr><th>Device</th><th>Type</th><th>Protocol</th><th>Status</th><th></th></tr></thead>
      <tbody>
        ${state.devices.map((d) => `
          <tr class="${d.status === 'isolated' ? 'row-flag' : ''}">
            <td class="mono" style="font-weight:600">${d.id} <span style="color:var(--text-2); font-weight:400">· ${d.name}</span></td>
            <td style="color:var(--text-2)">${d.type}</td>
            <td class="mono" style="color:var(--text-2)">${d.protocol}</td>
            <td>${d.status === 'isolated' ? badgeHtml('red', 'Isolated — under investigation') : badgeHtml('green', 'Secure · mTLS active')}</td>
            <td>${d.status === 'isolated' && can('ack') ? `<button class="btn btn-sm" data-restore="${d.id}">Restore</button>` : ''}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  `;
  table.querySelectorAll('[data-restore]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      await api('/api/device/restore', { method: 'POST', body: { deviceId: btn.dataset.restore } });
    });
  });
}

// ================================================================
// THREAT DETECTION (IDS + XAI)
// ================================================================
function renderIds(content) {
  content.innerHTML = `
    <div class="kpi-row">
      ${kpiCard('Detection Approach', 'Adaptive statistical', 'per-device online baseline', 'var(--violet)')}
      ${kpiCard('Explainability', 'Built-in (XAI)', 'score = feature contributions', 'var(--cyan)')}
      ${kpiCard('Alerts (session)', state.alerts.length, 'auto-isolated on trigger', 'var(--amber)')}
    </div>
    <div class="grid-2">
      <div class="panel panel-pad">
        <div class="section-label">LIVE ANOMALY SCORES BY DEVICE</div>
        <div id="idsScores"></div>
      </div>
      <div class="panel panel-pad">
        <div class="section-label">XAI — WHY THE LATEST ALERT FIRED</div>
        <div id="idsExplain"></div>
      </div>
    </div>
  `;
  renderIdsPanels();
}

function renderIdsPanels() {
  const scoresEl = document.getElementById('idsScores');
  const explainEl = document.getElementById('idsExplain');
  if (!scoresEl) return;

  const dets = Object.values(state.latestDetection);
  scoresEl.innerHTML = dets.length ? dets.map((d) => `
    <div class="flex-between" style="padding:9px 0; border-top:1px solid var(--line-soft)">
      <span class="mono" style="font-size:12.5px">${d.deviceId}</span>
      <div style="display:flex; align-items:center; gap:10px">
        <div class="feat-bar-track" style="width:100px">
          <div class="feat-bar-fill" style="width:${Math.min(100, d.score * 100)}%; background:${d.score > 0.62 ? 'var(--red)' : 'var(--green)'}"></div>
        </div>
        <span class="mono feat-value" style="width:auto">${d.calibrating ? 'calib.' : d.score.toFixed(2)}</span>
      </div>
    </div>
  `).join('') : `<div class="feed-empty">Waiting for telemetry from backend...</div>`;

  const lastAlert = state.alerts[0];
  if (!lastAlert) {
    explainEl.innerHTML = `<div class="feed-empty">No detections yet. Trigger an attack from the Overview page to see live XAI output.</div>`;
  } else {
    explainEl.innerHTML = `
      <div class="section-note" style="margin-bottom:14px">
        <strong style="color:var(--text-1)">${lastAlert.deviceId}</strong> flagged as
        <span style="color:var(--red)">${lastAlert.category}</span> — top contributing features:
      </div>
      ${lastAlert.explanation.map((f) => `
        <div class="feat-row">
          <span class="feat-label">${f.label}</span>
          <div class="feat-bar-track"><div class="feat-bar-fill" style="width:${Math.min(100, Math.abs(f.contribution) * 20)}%; background:var(--amber)"></div></div>
          <span class="feat-value mono">${f.rawValue}</span>
        </div>
      `).join('')}
    `;
  }
}

// ================================================================
// SECURITY INTERNALS — live, step-by-step cryptography (Crypto Lab)
// ================================================================
function renderCryptoLab(content) {
  content.innerHTML = `
    <div class="panel panel-pad mb-16">
      <div class="section-label">WHY THIS PAGE EXISTS</div>
      <div class="section-note" style="margin-bottom:0">
        Every number below is computed live by the backend using Node's real <code class="mono">crypto</code> module —
        nothing here is pre-scripted. Click a button and watch the actual transformation happen, byte by byte.
      </div>
    </div>

    <div class="grid-2 mb-16">
      <div class="panel panel-pad">
        <div class="flex-between mb-16">
          <div class="section-label" style="margin-bottom:0">AES-256-GCM — TELEMETRY CHANNEL ENCRYPTION</div>
          <button class="btn btn-solid-cyan btn-sm" id="runAes">Run Live Encryption</button>
        </div>
        <div id="aesOut" class="crypto-steps"><div class="feed-empty">Click "Run Live Encryption" to encrypt a real telemetry sample step by step.</div></div>
      </div>
      <div class="panel panel-pad">
        <div class="flex-between mb-16">
          <div class="section-label" style="margin-bottom:0">RSA-2048/PSS — PATCH SIGNING</div>
          <button class="btn btn-solid-cyan btn-sm" id="runRsa">Run Live Signing</button>
        </div>
        <div id="rsaOut" class="crypto-steps"><div class="feed-empty">Click "Run Live Signing" to sign a patch payload and verify it.</div></div>
      </div>
    </div>

    <div class="panel panel-pad mb-16">
      <div class="flex-between mb-16">
        <div class="section-label" style="margin-bottom:0">SHA-256 HASH CHAIN — HOW ONE AUDIT ENTRY IS BUILT</div>
        <button class="btn btn-solid-cyan btn-sm" id="runHash">Build Live Chain Entry</button>
      </div>
      <div id="hashOut" class="crypto-steps"><div class="feed-empty">Click to see exactly what string gets hashed for the next audit entry.</div></div>
    </div>

    <div class="grid-3">
      ${explainerCard('How the encryption works', 'Every telemetry frame is JSON, then encrypted with AES-256-GCM: a random 96-bit nonce is generated per message, the frame is encrypted with the shared 256-bit key, and a 128-bit authentication tag is produced alongside the ciphertext. On decrypt, the tag is checked FIRST — if even one bit of ciphertext changed in transit, decryption fails outright rather than silently returning wrong data. That is what "authenticated encryption" means in practice.')}
      ${explainerCard('How the AI engine works', 'The detector keeps a running mean/std per device per feature (frequency, voltage, command timing, auth validity) using Welford\'s online algorithm. Each new sample is scored as a weighted sum of how many standard deviations it sits from that device\'s own normal — not a global threshold. The score IS the explanation: every alert ships with the exact features that drove it, ranked by contribution, visible on the Threat Detection page.')}
      ${explainerCard('How the blockchain works', 'Every audit event gets SHA-256 hashed together with the previous event\'s hash — a hash chain. Every 4 entries, they\'re sealed into a block: a Merkle tree is built over the entries, and the block header (including that Merkle root) is hashed and chained to the previous block. Edit any entry\'s content — even one character — and the recomputed hash no longer matches what was stored, which the Audit Chain page\'s "Verify" button proves live.')}
    </div>
  `;

  document.getElementById('runAes').addEventListener('click', (e) => runCryptoDemo('aes', '/api/cryptolab/aes', 'aesOut', e.currentTarget));
  document.getElementById('runRsa').addEventListener('click', (e) => runCryptoDemo('rsa', '/api/cryptolab/rsa', 'rsaOut', e.currentTarget));
  document.getElementById('runHash').addEventListener('click', (e) => runCryptoDemo('hash', '/api/cryptolab/hashchain', 'hashOut', e.currentTarget));
}

function explainerCard(title, body) {
  return `<div class="panel panel-pad">
    <div class="section-label">${title.toUpperCase()}</div>
    <div class="section-note" style="margin-bottom:0">${body}</div>
  </div>`;
}

async function runCryptoDemo(kind, endpoint, targetId, btn) {
  if (btn) btn.disabled = true;
  const out = document.getElementById(targetId);
  out.innerHTML = '';
  try {
    const result = await api(endpoint, { method: 'POST' });
    result.steps.forEach((step, i) => {
      setTimeout(() => {
        const div = document.createElement('div');
        div.className = 'crypto-step fadein';
        div.innerHTML = `
          <div class="crypto-step-label">${escapeHtml(step.label)}</div>
          <div class="crypto-step-value mono">${escapeHtml(step.value)}</div>
        `;
        out.appendChild(div);
      }, i * 350);
    });
    setTimeout(() => {
      if (kind === 'aes') {
        const banner = document.createElement('div');
        banner.className = 'result-banner ' + (result.tamperResult.caught ? 'result-ok' : 'result-fail');
        banner.innerHTML = (result.tamperResult.caught ? '&#10003; ' : '&#10007; ') + result.tamperResult.note;
        out.appendChild(banner);
      }
      if (kind === 'rsa') {
        const banner = document.createElement('div');
        banner.className = 'result-banner ' + (result.forgedRejected ? 'result-ok' : 'result-fail');
        banner.innerHTML = result.forgedRejected ? '&#10003; Forged payload correctly rejected by signature check.' : '&#10007; Forged payload incorrectly accepted.';
        out.appendChild(banner);
      }
      if (btn) btn.disabled = false;
    }, result.steps.length * 350 + 100);
  } catch (err) {
    out.innerHTML = `<div class="result-banner result-fail">Error: ${escapeHtml(err.message)}</div>`;
    if (btn) btn.disabled = false;
  }
}


const PERMS = ['view', 'ack', 'config', 'patch', 'users', 'audit'];
const ROLE_PERMS = {
  admin: PERMS, engineer: ['view','ack','config','patch'], operator: ['view','ack'], auditor: ['view','audit'],
};

function renderAccess(content) {
  content.innerHTML = `
    <div class="panel panel-pad mb-16">
      <div class="section-label">ROLE × PERMISSION MATRIX</div>
      <table class="rbac-matrix">
        <thead><tr><th>Role</th>${PERMS.map((p) => `<th style="text-align:center; text-transform:capitalize">${p}</th>`).join('')}</tr></thead>
        <tbody>
          ${Object.entries(ROLES).map(([key, def]) => `
            <tr>
              <td style="color:${def.color}">${def.label}</td>
              ${PERMS.map((p) => `<td>${ROLE_PERMS[key].includes(p) ? '<span class="check-yes">&#10003;</span>' : '<span class="check-no">&mdash;</span>'}</td>`).join('')}
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
    <div class="panel panel-pad">
      <div class="section-label">CURRENT SESSION</div>
      <div style="display:flex; align-items:center; gap:10px; font-size:13px">
        <div class="avatar" style="background:${ROLES[state.session.role].color}">${state.session.user.slice(0,2).toUpperCase()}</div>
        <span style="font-weight:600">${escapeHtml(state.session.user)}</span>
        ${badgeHtml(roleTone(state.session.role), ROLES[state.session.role].label)}
        <span class="mono" style="color:var(--text-3); margin-left:auto">Token expires in 8h</span>
      </div>
    </div>
  `;
}
function roleTone(role) { return { admin: 'violet', engineer: 'cyan', operator: 'green', auditor: 'amber' }[role]; }

// ================================================================
// AUDIT CHAIN
// ================================================================
async function renderAudit(content) {
  content.innerHTML = `
    <div class="panel panel-pad flex-between mb-16">
      <div>
        <div class="section-label" style="margin-bottom:2px">IMMUTABLE HASH-CHAIN AUDIT LOG</div>
        <div class="section-note" style="margin-bottom:0">Every entry is SHA-256 hashed with the previous entry's hash, computed server-side and persisted to disk. Editing any row breaks the chain from that point forward.</div>
      </div>
      <div class="gap-8">
        <button class="btn btn-outline-red" id="tamperBtn">Simulate Tamper Attempt</button>
        <button class="btn btn-solid-cyan" id="verifyBtn">Verify Chain Integrity</button>
      </div>
    </div>
    <div id="verifyResult"></div>
    <div class="panel panel-pad mb-16" style="overflow-x:auto">
      <table>
        <thead><tr><th>#</th><th>Time</th><th>Actor</th><th>Action</th><th>Hash</th><th>Prev Hash</th></tr></thead>
        <tbody id="auditRows"></tbody>
      </table>
    </div>

    <div class="panel panel-pad flex-between mb-16">
      <div>
        <div class="section-label" style="margin-bottom:2px">BLOCK-STRUCTURED CHAIN (MERKLE TREE)</div>
        <div class="section-note" style="margin-bottom:0">Entries are batched into blocks of 4. Each block's header commits to a Merkle root over its transactions, and blocks chain to each other — the same tamper-evidence property as the flat log, with independently-provable sub-sets via Merkle proofs.</div>
      </div>
      <div class="gap-8">
        <button class="btn btn-outline-red" id="blockTamperBtn">Tamper a Sealed Block</button>
        <button class="btn" id="blockFlushBtn">Seal Pending Entries</button>
        <button class="btn btn-solid-cyan" id="blockVerifyBtn">Verify Block Chain</button>
      </div>
    </div>
    <div id="blockVerifyResult"></div>
    <div class="panel panel-pad" id="blocksPanel"></div>
  `;

  document.getElementById('verifyBtn').addEventListener('click', async () => {
    const result = await api('/api/audit/verify', { method: 'POST' });
    const el = document.getElementById('verifyResult');
    el.innerHTML = result.ok
      ? `<div class="result-banner result-ok">&#10003; Chain verified — all ${result.entriesVerified} entries intact, no tampering detected.</div>`
      : `<div class="result-banner result-fail">&#10007; INTEGRITY BREACH — ${result.reason} at entry #${result.brokenAt + 1}.</div>`;
  });
  document.getElementById('tamperBtn').addEventListener('click', async () => {
    await api('/api/audit/tamper-test', { method: 'POST' });
    await loadAuditRows();
    document.getElementById('verifyResult').innerHTML = '';
  });

  document.getElementById('blockVerifyBtn').addEventListener('click', async () => {
    const result = await api('/api/blockchain/verify', { method: 'POST' });
    const el = document.getElementById('blockVerifyResult');
    el.innerHTML = result.ok
      ? `<div class="result-banner result-ok">&#10003; Block chain verified — ${result.blocksVerified} blocks intact (${result.pendingEntries} entries still pending, not yet sealed).</div>`
      : `<div class="result-banner result-fail">&#10007; INTEGRITY BREACH in block #${result.brokenAtBlock} — ${result.reason}.</div>`;
  });
  document.getElementById('blockFlushBtn').addEventListener('click', async () => {
    await api('/api/blockchain/flush', { method: 'POST' });
    await loadBlocks();
  });
  document.getElementById('blockTamperBtn').addEventListener('click', async () => {
    await api('/api/blockchain/tamper', { method: 'POST', body: { blockIndex: 0 } });
    await loadBlocks();
    document.getElementById('blockVerifyResult').innerHTML = '';
  });

  await loadAuditRows();
  await loadBlocks();
}

async function loadBlocks() {
  const summary = await api('/api/blockchain/summary');
  const panel = document.getElementById('blocksPanel');
  if (!panel) return;
  if (!summary.blocks.length) {
    panel.innerHTML = `<div class="feed-empty">No blocks sealed yet (${summary.pendingCount} entries pending — click "Seal Pending Entries" or wait for 4 to accumulate naturally).</div>`;
    return;
  }
  panel.innerHTML = `<div class="block-row">${summary.blocks.map((b) => `
    <div class="block-card">
      <div class="block-card-index mono">BLOCK #${b.index}</div>
      <div class="block-card-row"><span>Tx count</span><span class="mono">${b.txCount}</span></div>
      <div class="block-card-row"><span>Block hash</span><span class="mono">${b.blockHash.slice(0,10)}&hellip;</span></div>
      <div class="block-card-row"><span>Merkle root</span><span class="mono">${b.merkleRoot.slice(0,10)}&hellip;</span></div>
      <div class="block-card-row"><span>Prev block</span><span class="mono">${b.prevBlockHash.slice(0,10)}&hellip;</span></div>
    </div>
  `).join('<div class="block-link">&rarr;</div>')}</div>
  ${summary.pendingCount ? `<div class="section-note" style="margin-top:14px; margin-bottom:0">${summary.pendingCount} entries pending in the next (unsealed) block.</div>` : ''}`;
}

async function loadAuditRows() {
  const rows = await api('/api/audit/log');
  state.auditLive = rows;
  renderAuditRows();
}
function renderAuditRows() {
  const tbody = document.getElementById('auditRows');
  if (!tbody) return;
  tbody.innerHTML = state.auditLive.slice(0, 60).map((e, i) => `
    <tr class="${e.action.includes('[MODIFIED]') ? 'row-flag' : ''}">
      <td class="mono">${state.auditLive.length - i}</td>
      <td class="mono" style="color:var(--text-2)">${new Date(e.ts).toLocaleTimeString()}</td>
      <td>${escapeHtml(e.actor)}</td>
      <td style="color:var(--text-2)">${escapeHtml(e.action)}</td>
      <td class="mono" style="color:var(--text-3)">${e.hash.slice(0, 12)}&hellip;</td>
      <td class="mono" style="color:var(--text-3)">${e.prevHash.slice(0, 12)}&hellip;</td>
    </tr>
  `).join('');
}

// ================================================================
// PATCH MANAGEMENT
// ================================================================
function renderPatch(content) {
  const p = state.patch;
  content.innerHTML = `
    <div class="panel panel-pad mb-16">
      <div class="flex-between mb-16">
        <div>
          <div class="section-label" style="margin-bottom:2px">PENDING SECURITY PATCH</div>
          <div class="mono" style="font-size:16px; font-weight:700">v${p.pending.version} — ${p.pending.cve}</div>
        </div>
        <div class="gap-8">
          <button class="btn btn-outline-amber" id="forgedBtn">Test Forged Patch</button>
          <button class="btn btn-solid-cyan" id="deployBtn">Verify &amp; Deploy</button>
        </div>
      </div>
      <div class="stage-row" id="stageRow"></div>
    </div>
    <div id="forgedResult"></div>
    <div class="panel panel-pad mb-16">
      <div class="section-label">DEVICE FIRMWARE VERSIONS</div>
      <table>
        <thead><tr><th>Device</th><th>Version</th><th>Status</th></tr></thead>
        <tbody id="deviceVersions"></tbody>
      </table>
    </div>
    <div class="panel panel-pad">
      <div class="section-label">ROLLOUT LOG</div>
      <div class="mono" id="patchLog" style="font-size:12px; display:flex; flex-direction:column; gap:6px">
        <div style="color:var(--text-3)">No rollout in progress.</div>
      </div>
    </div>
  `;

  renderPatchStages(p.status);
  renderDeviceVersions();

  document.getElementById('deployBtn').addEventListener('click', async () => {
    document.getElementById('deployBtn').disabled = true;
    document.getElementById('patchLog').innerHTML = '';
    const result = await api('/api/patch/deploy', { method: 'POST' });
    const st = await api('/api/state');
    state.patch = st.patch;
    renderPatchStages(state.patch.status);
    renderDeviceVersions();
    result.log.forEach((msg, i) => {
      setTimeout(() => {
        const logEl = document.getElementById('patchLog');
        if (logEl) logEl.innerHTML += `<div class="fadein"><span style="color:var(--text-3)">${new Date().toLocaleTimeString()}</span> — <span style="color:var(--text-2)">${escapeHtml(msg)}</span></div>`;
      }, i * 200);
    });
    document.getElementById('deployBtn').disabled = false;
  });

  document.getElementById('forgedBtn').addEventListener('click', async () => {
    const result = await api('/api/patch/forged-test', { method: 'POST' });
    document.getElementById('forgedResult').innerHTML = result.valid
      ? `<div class="result-banner result-fail">Forged patch incorrectly verified — this should never happen.</div>`
      : `<div class="result-banner result-ok">&#10003; Forged patch correctly REJECTED — RSA-2048 signature check failed as expected.</div>`;
  });
}

function renderPatchStages(status) {
  const el = document.getElementById('stageRow');
  if (!el) return;
  const stages = ['verifying', 'canary', 'rolling', 'complete'];
  const labels = ['Signature Verify', 'Canary Deploy', 'Staged Rollout', 'Complete'];
  const activeIdx = stages.indexOf(status);
  el.innerHTML = labels.map((l, i) => `<div class="stage ${i <= activeIdx ? 'active' : ''}">${l}</div>`).join('');
}
function renderDeviceVersions() {
  const tbody = document.getElementById('deviceVersions');
  if (!tbody || !state.patch) return;
  tbody.innerHTML = Object.entries(state.patch.deviceVersions).map(([id, v]) => `
    <tr><td class="mono" style="font-weight:600">${id}</td><td class="mono" style="color:var(--text-2)">v${v}</td>
    <td>${v === state.patch.pending.version ? badgeHtml('green', 'Up to date') : badgeHtml('amber', 'Patch pending')}</td></tr>
  `).join('');
}

// ---------------- Utility ----------------
function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
}

render();
