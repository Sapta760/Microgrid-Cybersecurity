/**
 * server.js — GRIDWATCH backend entry point.
 *
 * Zero external dependencies (Node built-ins only: http, fs, path, crypto) —
 * this sandbox has no npm registry access, and more importantly it means
 * this server runs anywhere Node runs with no install step at all.
 *
 * Wires together every module from the architecture diagram:
 *   Digital Twin -> MQTT Bus -> (Attack Sim injects here) -> IDS Engine (+XAI)
 *   -> Response & Audit Engine -> [isolation command back to twin]
 *                                -> SSE push -> SOC Dashboard (frontend/)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const { MqttBus } = require('./modules/mqtt-bus');
const { DigitalTwin, DEVICES } = require('./modules/digital-twin');
const { AttackSimulator } = require('./modules/attack-sim');
const { IdsEngine } = require('./modules/ids-engine');
const { ResponseAuditEngine } = require('./modules/response-audit-engine');
const { PatchManager } = require('./modules/patch-manager');
const { issueToken, verifyToken, hasPermission, ROLES } = require('./modules/auth');
const { TelemetryCipher } = require('./modules/crypto-utils');
const { BlockchainLite } = require('./modules/blockchain-lite');
const { CryptoLab } = require('./modules/crypto-lab');

const PORT = process.env.PORT || 8787;
const PUBLIC_DIR = path.join(__dirname, '..', 'frontend', 'public');

// ---------- Wire the system together ----------
const bus = new MqttBus();
const twin = new DigitalTwin(bus);
const attackSim = new AttackSimulator(twin, bus);
const ids = new IdsEngine(bus, { threshold: 0.62, calibrationSamples: 15 });
const audit = new ResponseAuditEngine(bus, twin);
const patchMgr = new PatchManager(bus, audit);
const telemetryCipher = new TelemetryCipher(); // demo of the AES-256-GCM channel cipher
const blockchain = new BlockchainLite();
const cryptoLab = new CryptoLab({ publicKey: patchMgr.publicKey, privateKey: patchMgr.privateKey });

// Feed every audit entry into the block-structured chain too.
bus.subscribe('audit/new-entry', (entry) => blockchain.addEntry(entry));

twin.start(1000);
audit.append('system', 'Controller boot — all modules initialized', {});

// ---------- SSE broadcast ----------
const sseClients = new Set();
function broadcast(event, data) {
  const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const res of sseClients) res.write(payload);
}
bus.subscribe('telemetry/#', (msg) => broadcast('telemetry', msg));
bus.subscribe('detection/#', (msg) => broadcast('detection', msg));
bus.subscribe('alerts/#', (msg) => broadcast('alert', msg));
bus.subscribe('command/#', (msg, topic) => broadcast('command', { topic, ...msg }));
bus.subscribe('audit/new-entry', (msg) => broadcast('audit', msg));
bus.subscribe('patch/log', (msg) => broadcast('patchlog', msg));
bus.subscribe('system/attack-sim', (msg) => broadcast('attacksim', msg));

// ---------- HTTP helpers ----------
function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => (data += c));
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(e); }
    });
    req.on('error', reject);
  });
}
function getAuth(req) {
  const header = req.headers['authorization'] || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  return verifyToken(token);
}
function requirePerm(req, res, perm) {
  const session = getAuth(req);
  if (!session) { sendJson(res, 401, { error: 'not authenticated' }); return null; }
  if (!hasPermission(session.role, perm)) {
    audit.append(session.user, `DENIED: attempted action requiring '${perm}' (role: ${session.role})`, { perm });
    sendJson(res, 403, { error: `role '${session.role}' lacks permission '${perm}'` });
    return null;
  }
  return session;
}

const MIME = { '.html': 'text/html', '.css': 'text/css', '.js': 'application/javascript', '.svg': 'image/svg+xml' };

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const pathname = parsed.pathname;

  // CORS (harmless for same-origin demo, useful if frontend is opened from file:// during dev)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  try {
    // ---------- API routes ----------
    if (pathname === '/api/login' && req.method === 'POST') {
      const { user, role } = await readBody(req);
      if (!user || !ROLES[role]) return sendJson(res, 400, { error: 'user and valid role required' });
      const token = issueToken(user, role);
      audit.append(user, `Authenticated session (role: ${role})`, {});
      return sendJson(res, 200, { token, user, role, perms: ROLES[role].perms });
    }

    if (pathname === '/api/state' && req.method === 'GET') {
      return sendJson(res, 200, {
        devices: twin.devices,
        patch: patchMgr.snapshot(),
        auditIntegrity: audit.verifyIntegrity(),
        attack: attackSim.status(),
      });
    }

    if (pathname === '/api/stream' && req.method === 'GET') {
      res.writeHead(200, {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      });
      res.write('event: hello\ndata: {}\n\n');
      sseClients.add(res);
      req.on('close', () => sseClients.delete(res));
      return;
    }

    if (pathname === '/api/attack/fdi' && req.method === 'POST') {
      const { deviceId } = await readBody(req);
      return sendJson(res, 200, attackSim.injectFDI(deviceId));
    }
    if (pathname === '/api/attack/replay' && req.method === 'POST') {
      const { deviceId } = await readBody(req);
      return sendJson(res, 200, attackSim.injectReplay(deviceId));
    }
    if (pathname === '/api/attack/dos' && req.method === 'POST') {
      const { deviceId } = await readBody(req);
      return sendJson(res, 200, attackSim.injectDoS(deviceId));
    }
    if (pathname === '/api/attack/unauth' && req.method === 'POST') {
      const { deviceId } = await readBody(req);
      return sendJson(res, 200, attackSim.injectUnauthCommand(deviceId));
    }
    if (pathname === '/api/attack/stop' && req.method === 'POST') {
      attackSim.stop();
      return sendJson(res, 200, { stopped: true });
    }

    if (pathname === '/api/device/restore' && req.method === 'POST') {
      const session = requirePerm(req, res, 'ack');
      if (!session) return;
      const { deviceId } = await readBody(req);
      audit.restore(deviceId, session.user);
      return sendJson(res, 200, { restored: deviceId });
    }

    if (pathname === '/api/audit/log' && req.method === 'GET') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      return sendJson(res, 200, audit.recent(200));
    }
    if (pathname === '/api/audit/verify' && req.method === 'POST') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      return sendJson(res, 200, audit.verifyIntegrity());
    }
    if (pathname === '/api/audit/tamper-test' && req.method === 'POST') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      const idx = audit.tamperTest();
      return sendJson(res, 200, { tamperedIndex: idx });
    }

    if (pathname === '/api/patch/deploy' && req.method === 'POST') {
      const session = requirePerm(req, res, 'patch');
      if (!session) return;
      const result = await patchMgr.rollout(session.user);
      return sendJson(res, 200, result);
    }
    if (pathname === '/api/patch/forged-test' && req.method === 'POST') {
      const session = requirePerm(req, res, 'patch');
      if (!session) return;
      return sendJson(res, 200, patchMgr.attemptForgedPatch());
    }

    if (pathname === '/api/crypto/demo' && req.method === 'GET') {
      // Live proof of the AES-256-GCM channel cipher, computed on request.
      const sample = { deviceId: 'DER-01', frequency: 50.01, voltage: 229.8, ts: Date.now() };
      const enc = telemetryCipher.encrypt(sample);
      const dec = telemetryCipher.decrypt(enc);
      let tamperDetected = false;
      try {
        const tampered = { ...enc, ciphertext: Buffer.from(enc.ciphertext, 'base64').fill(0, 0, 1).toString('base64') };
        telemetryCipher.decrypt(tampered);
      } catch {
        tamperDetected = true;
      }
      return sendJson(res, 200, { original: sample, encrypted: enc, decrypted: dec, roundTripOk: JSON.stringify(sample) === JSON.stringify(dec), tamperDetected });
    }

    // ---------- Crypto Lab: step-by-step, judge-visible cryptography ----------
    if (pathname === '/api/cryptolab/aes' && req.method === 'POST') {
      const session = getAuth(req);
      if (!session) return sendJson(res, 401, { error: 'not authenticated' });
      const latest = twin.devices[0];
      const sample = { deviceId: latest.id, frequency: 50 + (Math.random() - 0.5) * 0.02, voltage: 230 + (Math.random() - 0.5) * 1.2, ts: Date.now() };
      return sendJson(res, 200, cryptoLab.runAesDemo(sample));
    }
    if (pathname === '/api/cryptolab/rsa' && req.method === 'POST') {
      const session = getAuth(req);
      if (!session) return sendJson(res, 401, { error: 'not authenticated' });
      return sendJson(res, 200, cryptoLab.runRsaDemo('v2.4.0-patch'));
    }
    if (pathname === '/api/cryptolab/hashchain' && req.method === 'POST') {
      const session = getAuth(req);
      if (!session) return sendJson(res, 401, { error: 'not authenticated' });
      const last = audit.recent(1)[0];
      const prevHash = last ? last.hash : '0'.repeat(64);
      return sendJson(res, 200, cryptoLab.runHashChainDemo(session.user, 'Demo entry requested from Crypto Lab', {}, prevHash));
    }

    // ---------- Blockchain-lite: block-structured audit trail ----------
    if (pathname === '/api/blockchain/summary' && req.method === 'GET') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      return sendJson(res, 200, blockchain.summary());
    }
    if (pathname === '/api/blockchain/flush' && req.method === 'POST') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      const block = blockchain.flush();
      return sendJson(res, 200, { sealed: !!block, block });
    }
    if (pathname === '/api/blockchain/verify' && req.method === 'POST') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      return sendJson(res, 200, blockchain.verifyChain());
    }
    if (pathname === '/api/blockchain/tamper' && req.method === 'POST') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      const { blockIndex } = await readBody(req);
      const result = blockchain.tamperBlock(blockIndex);
      return sendJson(res, 200, { tampered: result !== null, blockIndex: result });
    }
    if (pathname === '/api/blockchain/proof' && req.method === 'GET') {
      const session = requirePerm(req, res, 'audit');
      if (!session) return;
      const blockIndex = parseInt(parsed.query.block, 10);
      const txIndex = parseInt(parsed.query.tx, 10);
      return sendJson(res, 200, blockchain.getProofFor(blockIndex, txIndex));
    }

    // ---------- Static file serving (frontend) ----------
    if (req.method === 'GET') {
      let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);
      if (!filePath.startsWith(PUBLIC_DIR)) return sendJson(res, 403, { error: 'forbidden' });
      fs.readFile(filePath, (err, data) => {
        if (err) return sendJson(res, 404, { error: 'not found' });
        const ext = path.extname(filePath);
        res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
        res.end(data);
      });
      return;
    }

    sendJson(res, 404, { error: 'not found' });
  } catch (err) {
    sendJson(res, 500, { error: String(err && err.message || err) });
  }
});

server.listen(PORT, () => {
  console.log(`GRIDWATCH backend running on http://localhost:${PORT}`);
  console.log(`Devices: ${DEVICES.map((d) => d.id).join(', ')}`);
});

module.exports = { server };
