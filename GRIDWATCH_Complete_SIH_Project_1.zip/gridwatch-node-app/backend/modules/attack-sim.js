/**
 * attack-sim.js — "Attack sim" box in the architecture diagram, feeding into
 * the MQTT layer's injection point. This is the test harness used to
 * demonstrate detection live — kept as a clearly separate module so it's
 * obvious to judges this is the demo trigger, not part of the production
 * control path.
 */
class AttackSimulator {
  constructor(twin, bus) {
    this.twin = twin;
    this.bus = bus;
    this.active = null; // { type, deviceId }
  }

  status() {
    return this.active;
  }

  stop() {
    if (this.active) {
      this.twin.clearAttackOverride(this.active.deviceId);
      this.bus.publish('system/attack-sim', { event: 'stopped', ...this.active });
    }
    this.active = null;
  }

  /** False Data Injection — spoofed frequency/voltage readings from a device. */
  injectFDI(deviceId = 'DER-01') {
    this.stop();
    this.active = { type: 'fdi', deviceId, startedAt: Date.now() };
    this.twin.setAttackOverride(deviceId, (sample) => ({
      ...sample,
      frequency: 50 + (Math.random() > 0.5 ? 1 : -1) * (0.4 + Math.random() * 0.8),
      voltage: 230 + (Math.random() - 0.5) * 60,
    }));
    this.bus.publish('system/attack-sim', { event: 'started', ...this.active });
    return this.active;
  }

  /** Replay attack — re-sends an identical earlier frame verbatim (no physical
   *  noise variation), which real sensor readings would never do exactly. */
  injectReplay(deviceId = 'BESS-01') {
    this.stop();
    this.active = { type: 'replay', deviceId, startedAt: Date.now() };
    const frozen = { frequency: 50.0, voltage: 230.0, power: 1.5 };
    this.twin.setAttackOverride(deviceId, (sample) => ({
      ...sample,
      frequency: frozen.frequency,
      voltage: frozen.voltage,
      power: frozen.power,
    }));
    this.bus.publish('system/attack-sim', { event: 'started', ...this.active });
    return this.active;
  }

  /** DoS flood — command channel gets flooded, collapsing inter-arrival time. */
  injectDoS(deviceId = 'WT-01') {
    this.stop();
    this.active = { type: 'dos', deviceId, startedAt: Date.now() };
    this.twin.setAttackOverride(deviceId, (sample, tick) => ({
      ...sample,
      commandTs: Date.now(), // near-zero inter-arrival vs. normal ~1000ms cadence
      voltage: sample.voltage + (Math.random() - 0.5) * 15,
    }));
    this.bus.publish('system/attack-sim', { event: 'started', ...this.active });
    return this.active;
  }

  /** Unauthorized command injection — spoofed control command with an invalid
   *  auth token, e.g. an attacker trying to trip a breaker without credentials. */
  injectUnauthCommand(deviceId = 'BRK-01') {
    this.stop();
    this.active = { type: 'unauth_command', deviceId, startedAt: Date.now() };
    this.twin.setAttackOverride(deviceId, (sample) => ({ ...sample, authValid: false }));
    this.bus.publish('command/' + deviceId, { action: 'open_breaker', authValid: false, source: 'unverified' });
    this.bus.publish('system/attack-sim', { event: 'started', ...this.active });
    return this.active;
  }
}

module.exports = { AttackSimulator };
