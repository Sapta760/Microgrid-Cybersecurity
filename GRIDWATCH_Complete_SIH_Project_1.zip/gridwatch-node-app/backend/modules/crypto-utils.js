/**
 * crypto-utils.js — all cryptographic primitives, using Node's built-in
 * `crypto` module only (no external dependency, no network fetch needed).
 *
 * - AES-256-GCM: secures the device <-> controller telemetry/command channel
 *   (confidentiality + integrity via the GCM auth tag).
 * - RSA-2048 (PSS/SHA-256): signs and verifies security patches, so the
 *   controller only ever applies updates from the trusted CA.
 * - SHA-256 hash chain: the immutable audit log — each entry's hash commits
 *   to the previous entry's hash, so any edit is detectable.
 */
const crypto = require('crypto');

// ---------- AES-256-GCM channel cipher ----------
class TelemetryCipher {
  constructor(key) {
    this.key = key || crypto.randomBytes(32);
  }
  encrypt(obj) {
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', this.key, iv);
    const ciphertext = Buffer.concat([cipher.update(JSON.stringify(obj), 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();
    return { iv: iv.toString('base64'), ciphertext: ciphertext.toString('base64'), tag: tag.toString('base64') };
  }
  decrypt({ iv, ciphertext, tag }) {
    const decipher = crypto.createDecipheriv('aes-256-gcm', this.key, Buffer.from(iv, 'base64'));
    decipher.setAuthTag(Buffer.from(tag, 'base64'));
    const plaintext = Buffer.concat([
      decipher.update(Buffer.from(ciphertext, 'base64')),
      decipher.final(), // throws if the GCM tag doesn't match -> tamper detected
    ]);
    return JSON.parse(plaintext.toString('utf8'));
  }
}

// ---------- RSA-2048 patch signing authority ----------
function generatePatchSigningKeys() {
  return crypto.generateKeyPairSync('rsa', {
    modulusLength: 2048,
    publicKeyEncoding: { type: 'spki', format: 'pem' },
    privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
  });
}
function signPatch(privateKeyPem, patchBuffer) {
  const signature = crypto.sign('sha256', patchBuffer, {
    key: privateKeyPem,
    padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
  });
  return signature.toString('base64');
}
function verifyPatch(publicKeyPem, patchBuffer, signatureB64) {
  try {
    return crypto.verify(
      'sha256',
      patchBuffer,
      { key: publicKeyPem, padding: crypto.constants.RSA_PKCS1_PSS_PADDING },
      Buffer.from(signatureB64, 'base64')
    );
  } catch {
    return false;
  }
}

// ---------- SHA-256 hash chain (audit log) ----------
function sha256Hex(input) {
  return crypto.createHash('sha256').update(input).digest('hex');
}
function chainEntry(prevHash, actor, action, metadata = {}) {
  const payload = actor + '|' + action + '|' + JSON.stringify(metadata) + '|' + prevHash;
  const hash = sha256Hex(payload);
  return { actor, action, metadata, prevHash, hash, ts: Date.now() };
}
function verifyChain(entries) {
  let expectedPrev = '0'.repeat(64);
  for (let i = 0; i < entries.length; i++) {
    const e = entries[i];
    if (e.prevHash !== expectedPrev) return { ok: false, brokenAt: i, reason: 'prev_hash link broken' };
    const recomputed = sha256Hex(e.actor + '|' + e.action + '|' + JSON.stringify(e.metadata) + '|' + e.prevHash);
    if (recomputed !== e.hash) return { ok: false, brokenAt: i, reason: 'entry content modified' };
    expectedPrev = e.hash;
  }
  return { ok: true, entriesVerified: entries.length };
}

module.exports = {
  TelemetryCipher,
  generatePatchSigningKeys,
  signPatch,
  verifyPatch,
  sha256Hex,
  chainEntry,
  verifyChain,
};
