/**
 * response-audit-engine.js — "Response & audit engine (isolates device, logs
 * event)" box in the architecture diagram. Does both jobs in one module
 * deliberately, matching the diagram's note that they always fire together.
 */
const fs = require('fs');
const path = require('path');
const { chainEntry, verifyChain } = require('./crypto-utils');

const LOG_PATH = path.join(__dirname, '..', 'data', 'audit-log.json');

class ResponseAuditEngine {
  constructor(bus, twin) {
    this.bus = bus;
    this.twin = twin;
    this.entries = this._load();

    this.bus.subscribe('alerts/#', (result) => this._handleAlert(result));
  }

  _load() {
    try {
      return JSON.parse(fs.readFileSync(LOG_PATH, 'utf8'));
    } catch {
      return [];
    }
  }
  _persist() {
    fs.writeFileSync(LOG_PATH, JSON.stringify(this.entries, null, 2));
  }

  append(actor, action, metadata = {}) {
    const prevHash = this.entries.length ? this.entries[this.entries.length - 1].hash : '0'.repeat(64);
    const entry = chainEntry(prevHash, actor, action, metadata);
    this.entries.push(entry);
    this._persist();
    this.bus.publish('audit/new-entry', entry);
    return entry;
  }

  _handleAlert(result) {
    // Response: isolate the device and publish the isolation command back
    // down onto the bus — the feedback loop shown in the diagram.
    this.twin.isolate(result.deviceId);
    this.bus.publish(`command/${result.deviceId}`, { action: 'isolate', reason: result.category, score: result.score });

    // Audit: log the detection + the automated response as one entry.
    this.append('ids-engine', `Auto-isolated ${result.deviceId} — ${result.category} (score ${result.score})`, {
      deviceId: result.deviceId,
      category: result.category,
      score: result.score,
      explanation: result.explanation,
    });
  }

  restore(deviceId, actor) {
    this.twin.restore(deviceId);
    this.bus.publish(`command/${deviceId}`, { action: 'restore' });
    this.append(actor, `Manually restored ${deviceId} to service`, { deviceId });
  }

  verifyIntegrity() {
    return verifyChain(this.entries);
  }

  /** Demo-only: simulate an attacker directly editing a stored log row. */
  tamperTest() {
    if (this.entries.length < 2) return null;
    const idx = Math.floor(this.entries.length / 2);
    this.entries[idx] = { ...this.entries[idx], action: this.entries[idx].action + ' [MODIFIED]' };
    this._persist();
    return idx;
  }

  recent(limit = 100) {
    return this.entries.slice(-limit).reverse();
  }
}

module.exports = { ResponseAuditEngine };
