/**
 * auth.js — Access control: RBAC + signed session tokens.
 *
 * Tokens are hand-rolled (base64url(header).base64url(payload).HMAC-SHA256
 * signature) rather than pulling in `jsonwebtoken` — same structure and
 * security property (server-signed, tamper-evident, stateless) as a real
 * JWT, implemented with only Node's built-in crypto since this sandbox
 * can't reach the npm registry. Swapping in the `jsonwebtoken` package
 * later is a one-line change; the token shape is compatible.
 */
const crypto = require('crypto');

const SECRET = crypto.randomBytes(32); // regenerated each server start — fine for a demo/hackathon session

const ROLES = {
  admin: { label: 'Administrator', perms: ['view', 'ack', 'config', 'patch', 'users', 'audit'] },
  engineer: { label: 'Engineer', perms: ['view', 'ack', 'config', 'patch'] },
  operator: { label: 'Operator', perms: ['view', 'ack'] },
  auditor: { label: 'Auditor', perms: ['view', 'audit'] },
};

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function b64urlDecode(str) {
  str = str.replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  return Buffer.from(str, 'base64').toString('utf8');
}

function issueToken(user, role) {
  const header = { alg: 'HS256', typ: 'JWT-LITE' };
  const payload = { user, role, iat: Date.now(), exp: Date.now() + 8 * 3600 * 1000 };
  const h = b64url(JSON.stringify(header));
  const p = b64url(JSON.stringify(payload));
  const sig = b64url(crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest());
  return `${h}.${p}.${sig}`;
}

function verifyToken(token) {
  if (!token) return null;
  const [h, p, sig] = token.split('.');
  if (!h || !p || !sig) return null;
  const expected = b64url(crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest());
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
  const payload = JSON.parse(b64urlDecode(p));
  if (payload.exp < Date.now()) return null;
  return payload;
}

function hasPermission(role, perm) {
  return !!ROLES[role] && ROLES[role].perms.includes(perm);
}

module.exports = { ROLES, issueToken, verifyToken, hasPermission };
