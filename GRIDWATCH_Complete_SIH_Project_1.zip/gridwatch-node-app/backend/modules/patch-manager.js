/**
 * patch-manager.js — Security Patch Management objective.
 *
 * Generates a real RSA-2048 keypair at startup (the "trusted CA"), signs a
 * demo patch payload, and runs a staged rollout (verify -> canary -> full
 * rollout) against the digital-twin devices — with genuine signature
 * verification at each step, and a forged-patch path that's shown to fail.
 */
const { generatePatchSigningKeys, signPatch, verifyPatch } = require('./crypto-utils');
const { DEVICES } = require('./digital-twin');

class PatchManager {
  constructor(bus, auditEngine) {
    this.bus = bus;
    this.auditEngine = auditEngine;
    const { publicKey, privateKey } = generatePatchSigningKeys();
    this.publicKey = publicKey;
    this.privateKey = privateKey; // in production this lives in an HSM, never on the controller

    this.currentVersion = '2.3.1';
    this.pendingPatch = {
      version: '2.4.0',
      cve: 'CVE-2026-1123 (DNP3 auth bypass)',
      payload: Buffer.from('firmware-v2.4.0-binary-contents-' + Date.now()),
    };
    this.pendingPatch.signature = signPatch(this.privateKey, this.pendingPatch.payload);
    this.deviceVersions = Object.fromEntries(DEVICES.map((d) => [d.id, this.currentVersion]));
    this.status = 'idle';
  }

  verifySignature(patchBuffer, signature) {
    return verifyPatch(this.publicKey, patchBuffer, signature);
  }

  async rollout(actor) {
    const log = [];
    const push = (msg) => {
      log.push(msg);
      this.bus.publish('patch/log', { msg, ts: Date.now() });
    };

    this.status = 'verifying';
    const valid = this.verifySignature(this.pendingPatch.payload, this.pendingPatch.signature);
    push(`Verifying signature for v${this.pendingPatch.version}... ${valid ? 'VALID (RSA-2048/PSS)' : 'INVALID — ABORTING'}`);
    if (!valid) {
      this.status = 'failed';
      this.auditEngine.append(actor, `Patch v${this.pendingPatch.version} rejected — signature verification failed`, {});
      return { ok: false, log };
    }

    this.status = 'canary';
    const canaryDevice = DEVICES[0].id;
    push(`Deploying to canary device ${canaryDevice}...`);
    await sleep(400);
    this.deviceVersions[canaryDevice] = this.pendingPatch.version;
    push(`Canary healthy — proceeding to full rollout.`);

    this.status = 'rolling';
    for (const d of DEVICES.slice(1)) {
      await sleep(150);
      this.deviceVersions[d.id] = this.pendingPatch.version;
      push(`${d.id} updated to v${this.pendingPatch.version}`);
    }

    this.currentVersion = this.pendingPatch.version;
    this.status = 'complete';
    this.auditEngine.append(actor, `Patch v${this.pendingPatch.version} deployed to all devices`, {
      devices: Object.keys(this.deviceVersions),
    });
    push('Rollout complete. Event recorded in audit chain.');
    return { ok: true, log };
  }

  /** Demo: attempt to deploy a forged patch — must fail verification. */
  attemptForgedPatch() {
    const forged = Buffer.from('forged-malicious-payload-' + Date.now());
    const valid = this.verifySignature(forged, this.pendingPatch.signature);
    return { valid, forgedContent: forged.toString() };
  }

  snapshot() {
    return {
      currentVersion: this.currentVersion,
      pending: { version: this.pendingPatch.version, cve: this.pendingPatch.cve },
      status: this.status,
      deviceVersions: this.deviceVersions,
    };
  }
}

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

module.exports = { PatchManager };
