/**
 * crypto-lab.js — makes encryption *visible*, not just present.
 *
 * The gap this fills: the earlier version of this project had working
 * crypto (AES-256-GCM, RSA-2048) but nothing on screen showed it actually
 * happening — a judge would have to take "it's encrypted" on faith. This
 * module runs the exact same primitives but returns every intermediate
 * value (key, IV, ciphertext, auth tag — all as hex) so the frontend can
 * render the real transformation step by step, live, on a real telemetry
 * sample.
 */
const crypto = require('crypto');

class CryptoLab {
  constructor({ publicKey, privateKey }) {
    this.aesKey = crypto.randomBytes(32); // AES-256 = 32-byte key
    this.publicKey = publicKey;
    this.privateKey = privateKey;
  }

  /**
   * Full step-by-step AES-256-GCM walkthrough on a real telemetry sample.
   * Returns every stage as hex so the UI can render "plaintext -> key+IV ->
   * ciphertext -> tag -> decrypted" without hiding any of the math.
   */
  runAesDemo(sample) {
    const steps = [];
    const plaintext = JSON.stringify(sample);
    steps.push({ label: 'Plaintext telemetry frame (what the device measured)', value: plaintext });

    const iv = crypto.randomBytes(12); // 96-bit nonce, unique per message
    steps.push({ label: 'Random 96-bit IV/nonce generated for this message', value: iv.toString('hex') });
    steps.push({ label: 'AES-256 key (device-controller shared secret)', value: this.aesKey.toString('hex') });

    const cipher = crypto.createCipheriv('aes-256-gcm', this.aesKey, iv);
    const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();
    steps.push({ label: 'Ciphertext (AES-256-GCM output — this is what actually travels over the wire)', value: ciphertext.toString('hex') });
    steps.push({ label: 'GCM authentication tag (128-bit integrity/tamper-check value)', value: tag.toString('hex') });

    // Decrypt back, to prove round-trip correctness
    const decipher = crypto.createDecipheriv('aes-256-gcm', this.aesKey, iv);
    decipher.setAuthTag(tag);
    const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
    steps.push({ label: 'Decrypted at the controller (round-trip verified)', value: decrypted });

    // Tamper demonstration: flip one bit of ciphertext, prove GCM catches it
    let tamperResult;
    try {
      const tampered = Buffer.from(ciphertext); tampered[0] ^= 0xff;
      const d2 = crypto.createDecipheriv('aes-256-gcm', this.aesKey, iv);
      d2.setAuthTag(tag);
      Buffer.concat([d2.update(tampered), d2.final()]);
      tamperResult = { caught: false, note: 'THIS SHOULD NEVER HAPPEN — tamper was not detected' };
    } catch (e) {
      tamperResult = { caught: true, note: 'GCM auth tag verification failed as expected — modified ciphertext was REJECTED before it could be used' };
    }

    return { steps, tamperResult, roundTripOk: decrypted === plaintext };
  }

  /**
   * Full step-by-step RSA-2048/PSS signing walkthrough on a patch payload.
   */
  runRsaDemo(patchLabel) {
    const steps = [];
    const payload = Buffer.from(`${patchLabel}-binary-contents-${Date.now()}`);
    steps.push({ label: 'Patch payload (bytes to be signed)', value: payload.toString('hex').slice(0, 120) + '…' });

    const hash = crypto.createHash('sha256').update(payload).digest('hex');
    steps.push({ label: 'SHA-256 digest of the payload', value: hash });

    const signature = crypto.sign('sha256', payload, {
      key: this.privateKey, padding: crypto.constants.RSA_PKCS1_PSS_PADDING,
    });
    steps.push({ label: 'RSA-2048/PSS signature (computed with the CA private key — never leaves the CA)', value: signature.toString('hex').slice(0, 120) + '…' });

    const validOnLegit = crypto.verify('sha256', payload, { key: this.publicKey, padding: crypto.constants.RSA_PKCS1_PSS_PADDING }, signature);
    steps.push({ label: 'Verification against CA public key (controller-side check)', value: validOnLegit ? 'VALID — signature matches' : 'INVALID' });

    const forged = Buffer.from(`${patchLabel}-MALICIOUS-PAYLOAD-${Date.now()}`);
    let forgedValid;
    try {
      forgedValid = crypto.verify('sha256', forged, { key: this.publicKey, padding: crypto.constants.RSA_PKCS1_PSS_PADDING }, signature);
    } catch { forgedValid = false; }
    steps.push({ label: 'Attempting to verify a FORGED payload against the same signature', value: forgedValid ? 'INCORRECTLY VALID (should never happen)' : 'REJECTED — forged payload does not match signature' });

    return { steps, legitimateValid: validOnLegit, forgedRejected: !forgedValid };
  }

  /**
   * Step-by-step SHA-256 hash-chain construction — shows the exact string
   * being hashed, not just the final hash, for one audit entry.
   */
  runHashChainDemo(actor, action, metadata, prevHash) {
    const steps = [];
    const payload = `${actor}|${action}|${JSON.stringify(metadata)}|${prevHash}`;
    steps.push({ label: 'Previous entry\'s hash (this entry commits to it)', value: prevHash });
    steps.push({ label: 'Concatenated string being hashed: actor|action|metadata|prevHash', value: payload });
    const hash = crypto.createHash('sha256').update(payload).digest('hex');
    steps.push({ label: 'SHA-256(payload) — this entry\'s hash', value: hash });
    steps.push({ label: 'Why this is tamper-evident', value: 'Changing any character above changes this hash completely (avalanche effect), which breaks every hash after it in the chain — so a single edited row is detectable no matter how far back it is.' });
    return { steps, hash };
  }
}

module.exports = { CryptoLab };
