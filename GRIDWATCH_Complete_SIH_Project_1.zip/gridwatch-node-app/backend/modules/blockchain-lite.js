/**
 * blockchain-lite.js — turns the flat SHA-256 hash-chain audit log into an
 * actual block structure: entries are batched into blocks of N, each block
 * computes a real Merkle root over its entries' hashes, and blocks
 * themselves are chained (block.prevBlockHash -> previous block.blockHash).
 *
 * This is the "blockchain" the PS asks for, built honestly: no consensus
 * mechanism (there's one trusted controller, so consensus buys nothing —
 * see README for why that'd be buzzword-stacking), but the two properties
 * that actually matter for an audit trail — tamper-evidence and independent
 * verifiability via Merkle proofs — are real and testable here.
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const CHAIN_PATH = path.join(__dirname, '..', 'data', 'blockchain.json');
const BLOCK_SIZE = 4;

function sha256Hex(input) {
  return crypto.createHash('sha256').update(input).digest('hex');
}

/** Standard binary Merkle tree over a list of hex leaf hashes. */
function merkleRoot(leaves) {
  if (leaves.length === 0) return sha256Hex('');
  let level = [...leaves];
  const layers = [level];
  while (level.length > 1) {
    const next = [];
    for (let i = 0; i < level.length; i += 2) {
      const left = level[i];
      const right = i + 1 < level.length ? level[i + 1] : level[i]; // duplicate last if odd
      next.push(sha256Hex(left + right));
    }
    level = next;
    layers.push(level);
  }
  return { root: level[0], layers };
}

/** Merkle proof: sibling hashes needed to recompute the root from one leaf. */
function merkleProof(layers, leafIndex) {
  const proof = [];
  let idx = leafIndex;
  for (let l = 0; l < layers.length - 1; l++) {
    const layer = layers[l];
    const isRightNode = idx % 2 === 1;
    const siblingIdx = isRightNode ? idx - 1 : idx + 1;
    const sibling = siblingIdx < layer.length ? layer[siblingIdx] : layer[idx];
    proof.push({ hash: sibling, position: isRightNode ? 'left' : 'right' });
    idx = Math.floor(idx / 2);
  }
  return proof;
}
function verifyMerkleProof(leafHash, proof, expectedRoot) {
  let hash = leafHash;
  for (const step of proof) {
    hash = step.position === 'left' ? sha256Hex(step.hash + hash) : sha256Hex(hash + step.hash);
  }
  return hash === expectedRoot;
}

class BlockchainLite {
  constructor() {
    this.blocks = this._load();
    this.pending = []; // entries not yet batched into a block
  }
  _load() {
    try { return JSON.parse(fs.readFileSync(CHAIN_PATH, 'utf8')); } catch { return []; }
  }
  _persist() { fs.writeFileSync(CHAIN_PATH, JSON.stringify(this.blocks, null, 2)); }

  /** Feed a new audit-log entry in. Batches into a block once BLOCK_SIZE is reached. */
  addEntry(entry) {
    this.pending.push(entry);
    if (this.pending.length >= BLOCK_SIZE) this._sealBlock();
  }

  _sealBlock() {
    const leaves = this.pending.map((e) => e.hash);
    const { root, layers } = merkleRoot(leaves);
    const prevBlockHash = this.blocks.length ? this.blocks[this.blocks.length - 1].blockHash : '0'.repeat(64);
    const index = this.blocks.length;
    const header = { index, prevBlockHash, merkleRoot: root, ts: Date.now(), txCount: this.pending.length };
    const blockHash = sha256Hex(JSON.stringify(header));
    const block = { ...header, blockHash, transactions: this.pending, merkleLayers: layers.map((l) => l) };
    this.blocks.push(block);
    this._persist();
    this.pending = [];
    return block;
  }

  /** Force-seal whatever's pending (demo convenience, so judges don't have to wait for BLOCK_SIZE entries). */
  flush() {
    if (this.pending.length > 0) return this._sealBlock();
    return null;
  }

  verifyChain() {
    let expectedPrev = '0'.repeat(64);
    for (const block of this.blocks) {
      if (block.prevBlockHash !== expectedPrev) {
        return { ok: false, brokenAtBlock: block.index, reason: 'block prevBlockHash link broken' };
      }
      // Recompute each transaction's hash FROM ITS CONTENT — this is the check that
      // actually catches tampering. Trusting the stored `hash` field and only
      // re-deriving the Merkle root from it would miss an edit that changes a
      // transaction's content but leaves its (now-stale) hash field untouched.
      const recomputedLeaves = block.transactions.map((t) =>
        sha256Hex(`${t.actor}|${t.action}|${JSON.stringify(t.metadata)}|${t.prevHash}`)
      );
      for (let i = 0; i < block.transactions.length; i++) {
        if (recomputedLeaves[i] !== block.transactions[i].hash) {
          return {
            ok: false, brokenAtBlock: block.index, brokenAtTx: i,
            reason: `transaction ${i} content does not match its stored hash — this entry was directly edited`,
          };
        }
      }
      const { root } = merkleRoot(recomputedLeaves);
      if (root !== block.merkleRoot) {
        return { ok: false, brokenAtBlock: block.index, reason: 'Merkle root does not match block transactions' };
      }
      const header = { index: block.index, prevBlockHash: block.prevBlockHash, merkleRoot: block.merkleRoot, ts: block.ts, txCount: block.txCount };
      if (sha256Hex(JSON.stringify(header)) !== block.blockHash) {
        return { ok: false, brokenAtBlock: block.index, reason: 'block header hash mismatch' };
      }
      expectedPrev = block.blockHash;
    }
    return { ok: true, blocksVerified: this.blocks.length, pendingEntries: this.pending.length };
  }

  /** Demo: tamper with a transaction inside a sealed block (should break Merkle root check). */
  tamperBlock(blockIndex) {
    const block = this.blocks[blockIndex];
    if (!block || !block.transactions.length) return null;
    block.transactions[0] = { ...block.transactions[0], action: block.transactions[0].action + ' [TAMPERED]' };
    this._persist();
    return blockIndex;
  }

  getProofFor(blockIndex, txIndex) {
    const block = this.blocks[blockIndex];
    if (!block) return null;
    const leaves = block.transactions.map((t) => sha256Hex(`${t.actor}|${t.action}|${JSON.stringify(t.metadata)}|${t.prevHash}`));
    const { layers } = merkleRoot(leaves);
    const proof = merkleProof(layers, txIndex);
    const valid = verifyMerkleProof(leaves[txIndex], proof, block.merkleRoot);
    return { leaf: leaves[txIndex], proof, root: block.merkleRoot, valid };
  }

  summary() {
    return {
      blockCount: this.blocks.length,
      pendingCount: this.pending.length,
      blocks: this.blocks.map((b) => ({
        index: b.index, blockHash: b.blockHash, prevBlockHash: b.prevBlockHash,
        merkleRoot: b.merkleRoot, txCount: b.txCount, ts: b.ts,
      })),
    };
  }
}

module.exports = { BlockchainLite, sha256Hex, merkleRoot, merkleProof, verifyMerkleProof };
