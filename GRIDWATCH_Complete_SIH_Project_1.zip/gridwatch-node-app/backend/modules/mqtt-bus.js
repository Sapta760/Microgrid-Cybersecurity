/**
 * mqtt-bus.js — MQTT-style topic pub/sub communication layer.
 *
 * This is the "MQTT communication layer" box in the architecture diagram.
 * It is implemented as an in-process topic bus (EventEmitter-based) rather
 * than wiring up a real broker, because this sandbox has no network access
 * to install one (aedes/mosquitto). The topic model, message shape, and
 * pub/sub semantics are deliberately identical to real MQTT so swapping in
 * an actual broker later is a drop-in change, not a redesign:
 *
 *   bus.publish('telemetry/DER-01', {...})   <->  mqttClient.publish(topic, JSON.stringify(msg))
 *   bus.subscribe('telemetry/#', handler)    <->  mqttClient.subscribe('telemetry/#')
 *
 * Wildcard support: '#' matches any suffix (multi-level), '+' matches
 * exactly one topic level — same semantics as real MQTT.
 */
const EventEmitter = require('events');

class MqttBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(100);
    this.log = []; // recent message trace, for debugging/demo visibility
  }

  publish(topic, message) {
    const envelope = { topic, message, ts: Date.now() };
    this.log.push(envelope);
    if (this.log.length > 500) this.log.shift();
    this.emit('__raw__', envelope);
    this.emit(topic, message); // exact-match subscribers
  }

  subscribe(pattern, handler) {
    if (!pattern.includes('#') && !pattern.includes('+')) {
      this.on(pattern, handler);
      return () => this.off(pattern, handler);
    }
    // wildcard subscription — listen to the raw stream and filter
    const regex = wildcardToRegex(pattern);
    const wrapped = (envelope) => {
      if (regex.test(envelope.topic)) handler(envelope.message, envelope.topic);
    };
    this.on('__raw__', wrapped);
    return () => this.off('__raw__', wrapped);
  }
}

function wildcardToRegex(pattern) {
  const escaped = pattern
    .split('/')
    .map((seg) => {
      if (seg === '#') return '.*';
      if (seg === '+') return '[^/]+';
      return seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    })
    .join('/');
  return new RegExp('^' + escaped + '$');
}

module.exports = { MqttBus, wildcardToRegex };
