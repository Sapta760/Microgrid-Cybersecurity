/**
 * digital-twin.js — "Simulated microgrid" box in the architecture diagram.
 *
 * Simulates 6 microgrid devices (2x solar, battery, wind, smart meter, breaker
 * controller) publishing realistic telemetry onto the MQTT-style bus every
 * second: frequency (Hz), voltage (V), power (kW), with a diurnal load/solar
 * pattern and small physical noise — not just random numbers, since a
 * detector trained on pure noise would trivially "detect" anything.
 */
const DEVICES = [
  { id: 'DER-01', name: 'Solar Array A', type: 'Solar PV', protocol: 'IEC 61850' },
  { id: 'DER-02', name: 'Solar Array B', type: 'Solar PV', protocol: 'IEC 61850' },
  { id: 'BESS-01', name: 'Battery Bank 1', type: 'Storage', protocol: 'DNP3' },
  { id: 'WT-01', name: 'Wind Turbine 1', type: 'Wind', protocol: 'Modbus TCP' },
  { id: 'MTR-01', name: 'Smart Meter Grid-Tie', type: 'Metering', protocol: 'DNP3' },
  { id: 'BRK-01', name: 'Breaker Controller', type: 'Switchgear', protocol: 'IEC 61850' },
];

class DigitalTwin {
  constructor(bus) {
    this.bus = bus;
    this.tick = 0;
    this.deviceState = Object.fromEntries(
      DEVICES.map((d) => [d.id, { status: 'secure', lastCommandAt: Date.now() }])
    );
    // per-device override hooks the attack-sim module can install to corrupt
    // an otherwise-normal reading before it's published
    this.attackOverrides = {};
  }

  get devices() {
    return DEVICES.map((d) => ({ ...d, status: this.deviceState[d.id].status }));
  }

  isolate(deviceId) {
    if (this.deviceState[deviceId]) this.deviceState[deviceId].status = 'isolated';
  }

  restore(deviceId) {
    if (this.deviceState[deviceId]) this.deviceState[deviceId].status = 'secure';
  }

  setAttackOverride(deviceId, fn) {
    this.attackOverrides[deviceId] = fn;
  }
  clearAttackOverride(deviceId) {
    delete this.attackOverrides[deviceId];
  }

  start(intervalMs = 1000) {
    this.timer = setInterval(() => this._step(), intervalMs);
  }
  stop() {
    clearInterval(this.timer);
  }

  _step() {
    this.tick += 1;
    const diurnal = 1 + 0.08 * Math.sin((this.tick / 60) * (2 * Math.PI));

    for (const d of DEVICES) {
      if (this.deviceState[d.id].status === 'isolated') continue; // isolated devices go silent

      let sample = {
        deviceId: d.id,
        ts: Date.now(),
        frequency: 50 + gauss(0, 0.008),
        voltage: 230 * diurnal + gauss(0, 0.5),
        power: (d.type === 'Solar PV' ? 3.2 : d.type === 'Wind' ? 2.1 : 1.5) * diurnal + gauss(0, 0.1),
        commandTs: Date.now(),
        authValid: true,
        seq: this.tick,
      };

      const override = this.attackOverrides[d.id];
      if (override) sample = override(sample, this.tick);

      this.bus.publish(`telemetry/${d.id}`, sample);
    }
  }
}

function gauss(mean, std) {
  // Box-Muller
  const u1 = Math.random() || 1e-9;
  const u2 = Math.random();
  const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  return mean + z * std;
}

module.exports = { DigitalTwin, DEVICES };
